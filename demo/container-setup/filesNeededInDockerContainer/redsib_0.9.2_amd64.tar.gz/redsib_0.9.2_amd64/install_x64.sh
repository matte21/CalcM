echo 'SPARQL Subscription Engine INSTALLER X64'
echo ''
cd deb_amd64

echo 'INSTALLING PRELIMINARY LIBRARIES'
sudo dpkg -i libyajl2_2.0.4-4_amd64.deb
sudo dpkg -i libraptor2-0_2.0.10-1_amd64.deb
sudo dpkg -i librasqal3_0.9.30-1_amd64.deb
sudo dpkg -i librdf0_1.0.16-UNIBO_1_amd64.deb

# In the old version of the script, redland
# was installed using a raw cp instuction:
# sudo cp -R redland /usr/local/lib
# now that we have the .deb file we use dpkg
sudo dpkg -i redland_1.0.16-1_amd64.deb
sudo dpkg -i libdb5.3_5.3.15-4ubuntu1_amd64.deb

sudo ldconfig
echo ''
echo 'INSTALLING REDSIB'
sudo dpkg -i libwhiteboard_2.3_amd64.deb
sudo dpkg -i libwhiteboard-dev_2.3_amd64.deb
sudo dpkg -i whiteboard_2.0-beta1_amd64.deb
sudo dpkg -i whiteboard-sib-access_2.0-beta1_amd64.deb
sudo dpkg -i sib-tcp_0.81_amd64.deb
sudo dpkg -i redsibd_0.9.2-1_amd64.deb

echo ''
cd .. 
./virtuoso_install.sh


