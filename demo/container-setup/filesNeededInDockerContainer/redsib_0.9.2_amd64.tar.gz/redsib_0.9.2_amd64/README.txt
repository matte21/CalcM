Redland Smart M3 (RedSIB), developed by ARCES-DISI (University of Bologna)
Implementation based on Nokia C Smart M3.

Release 0.9.2 (05/02/2015)
- Fixed bug on literal object data types in SPARQL subscriptions
- Fixed bug on variables names within other variables names in SPARQL subscriptions (e.g. ?x ?xy)
- Berkeley DB storage support for RedLand updated to version 5.3.15
- Source codes have been moved to a different package (redsibd_0.9.2-src.tar.gz). Source codes include all the external libraries (libxml, raptor, rasqal, Redland), the Smart-M3 specific libraries (whiteboard) and the Smart-M3 daemons (redsibd, sib-tcp). The folder includes instructions to set-up the LUNA Eclipse workspace to rebuild and debug the project

Release 0.901
- Fixed some BUGs (sib-tcp & subscribe, virtuoso, sparql update) 


Release 0.9 (tested on ubuntu 12.04):

- New multithread independent internal architecture for SPARQL subscriptions  .

- SPARQL Subscribe Accelerator 
  ( Only SELECT supported )

- SPARQL Update Supported 
  ( INSERT, DELETE, INSERT DATA, DELETE DATA Perform these as common queries )

- SPARQL Update extended with SIB time and delay support. 
  ( Check SEPs examples  ;) )

- Virtuoso Opensource storage support 
  ( Extremely recommended for strongly persistent usage and big data. 
    Just run using option --storage-virtuoso 
    The REDLAND Modified from UNIBO is mandatory.

    Take a look here if you need best performances: 
    http://www.openlinksw.com/dataspace/doc/dav/wiki/Main/VirtRDFPerformanceTuning 
  )


Release Alpha 0.4.1:

- Added SPARQL subscribe support .
  ( Available new alpha pythonKPI to test, onky m3_kp will support it )
  In next releases an optimized algorithm will be improved to make it more faster.

- Better big size triplestore support.

- In order to simplify, black nodes are not managed anymore in the SIB.
  Every inserted triple coming from RDF-XML with blank nodes will be discharged. 

Release 0.3.12:

- Improvements in performances for subscription operations when massive sets of 
  triples are inserted or removed.

- Better threads managements for subscriptions.

Release 0.3.11:

- Fixed some bugs.

Release 0.3.1:

- RDFXML support on insert, remove and update operation. Check document in DOCS.

- Reasoning RDF++ (available as options, check in 'redsibd --help')

- Sqlite support for DB (slow but completely persistent)

- Fixed some bugs.


Release 0.2.1:

What offers more compared to official Smart M3:

- It offers stability of 10-year experience of redland triplestore. BDB default database 
  offers very fast performances.

- It can manage RDF subscriptions with a new fast algorithm.

- It execute SPARQL query.

- TCP module will not crash due to manage subscriptions with disconnected KPs..
  Garbage collector will remove still-active subscriptions with disconnected KPs.

What not supported anymore:
- Wilbour query are not supported anymore.


NB
Sib-tcp v0.7 is with subsciption suppression control.
Load 'sib-tcp -sub-wake-fr -1' to disable socket exporer.



INSTALL:
Requirements: Ubuntu >= 10.04

For x86 architecture just execute install.sh for install 
the debian packages in right order.
No additional package is required.

UNINSTALL:
Just execute uninstall.sh, everything will be completely removed.

LAUNCHING:
Execute first 'redsibd' and next 'sib-tcp' in two different terminals.
redsibd is available with --help options.

COMPILE or HACK: 
For compiling it's necessary to install following packages with this line  (in ubuntu 12.04) :

> sudo apt-get install autoconf libtool libexpat1-dev uuid-dev libdbus-1-dev libdbus-glib-1-dev librdf0 librdf0-dev gtk-doc-tools debhelper

Even if redland is still installed with packages it's necessary to download from http://librdf.org/
last package redland-1.0.XX.tar.gz, unpack, compile and install with autogen.sh, make and make install.

Following to compile single redsib packages it's necessary to run:
>./autogen.sh
>make

and alternatively:
-make install   	> to direct install

-dpkg-buildpackage 	> to create a debian package  


IMPORTANT:
redsibd and Nokia sibd can be installed both on the same machine.

If you still have official Smart M3 installed pay attention to libwhitedoard and libwhitedoard-dev
library replication in /usr/local/lib and in usr/lib. In this case just remove old libraries.
With official parser SPARQL query will not work.


SSAP specifications for SPARQL are included in Sofia D5.23 and in DOCS document.
SPARQL API are available in C#, Java and Python. 



For any question:

Francesco Morandi    <fmorandi@arces.unibo.it> <francescomorandi84@libero.it>

