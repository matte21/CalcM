
For automatical startup EVEN with NO graphical interface 
do the following operations:


Create a file called sibload.sh in /etc/init.d/
with this content (if you want a different storage 
option just change):


#! /bin/sh
# /etc/init.d/sibload.sh
### BEGIN INIT INFO
# Provides:          noip
# Required-Start:    $remote_fs $syslog
# Required-Stop:     $remote_fs $syslog
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: Simple script to start a program at boot
# Description:       A simple script which will start / stop a program a boot / shutdown.
### END INIT INFO
# If you want a command to always run, put it here
# Carry out specific functions when asked to by the system
case "$1" in
start)
echo "Starting redsibd on virtuoso"
# run application you want to start
eval `dbus-launch --sh-syntax`
export DBUS_SESSION_BUS_ADDRESS
redsibd --storage-virtuoso-p=="dsn='VOS', host='127.0.0.1', user='dba',password='your_password'" &
sleep 1 
sib-tcp &
;;
stop)
echo "Stopping redsibd on virtuoso"
# kill application you want to stop
killall redsibd
killall sib-tcp
;;
*)
echo "Usage: sudo service sibload.sh {start|stop}"
exit 1
;;
esac
exit 0



When it is done launch :

sudo update-rc.d sibload.sh defaults 99

The sib will set up at boot ;) Bye.





