echo 'Raspberry Smart-M3 SEB 0.9 Installation'
echo ''
echo 'Installing (manually) Redland-UNIBO'
cd redland_libs
sudo cp -R * /usr/local/lib
sudo ln -s /usr/local/lib/librdf.so.0.0 /usr/local/lib/librdf.so.0
sudo ln -s /usr/local/lib/librdf.so.0 /usr/local/lib/librdf.so
sudo ldconfig
cd ..
echo ''
echo 'Installing libraries'
sudo apt-get update 
sudo apt-get install libdb5.3 librasqal3 libraptor2-0
echo 'Installing SMART M3'
sudo dpkg -i libwhiteboard_2.3_armhf.deb
sudo dpkg -i libwhiteboard-dev_2.3_armhf.deb
sudo dpkg -i whiteboard_2.0-beta1_armhf.deb
sudo dpkg -i whiteboard-sib-access_2.0-beta1_armhf.deb
sudo dpkg -i redsibd_0.9.01_armhf.deb
sudo dpkg -i sib-tcp_0.81_armhf.deb
sudo chmod +x virtuoso_install.sh
./virtuoso_install.sh
