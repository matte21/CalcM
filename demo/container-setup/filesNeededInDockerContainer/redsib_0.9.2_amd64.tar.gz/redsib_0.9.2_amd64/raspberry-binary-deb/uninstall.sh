echo 'SMART M3 REDLAND UNINSTALLER'
sudo apt-get remove libwhiteboard-dev
sudo apt-get remove libwhiteboard 
sudo apt-get remove whiteboard 
sudo apt-get remove whiteboard-sib-access 
sudo apt-get remove sib-tcp
sudo apt-get remove redsibd

