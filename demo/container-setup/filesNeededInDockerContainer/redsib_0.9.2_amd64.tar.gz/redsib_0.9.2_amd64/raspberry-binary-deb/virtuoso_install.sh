echo ""
echo ""
read -p "Would you like to install Virtuoso support? y/n ( Recommended, 25-30 MB required ): " RESP
if [ "$RESP" = "y" ]; then
  echo "Installing Virtuoso..";  sudo apt-get install unixodbc virtuoso-opensource;
else
  echo "Ok.. Bye"
fi

