This example shows how the sensor-lamp problem can 
be easily extended to a multi-device scenario.
