import sys
from smart_m3.m3_kp_api import *
import uuid
import datetime
import os
import argparse
from time import time
from time import sleep
import random

############################## AGENTS ###############################

######### AGENT I "turn lamps on"
# CONTEXT "detect lamps on"

context_I= '\
PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#> \
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> \
PREFIX owl:<http://www.w3.org/2002/07/owl#> \
PREFIX xsd:<http://www.w3.org/2001/XMLSchema#> \
PREFIX unibo:<http://www.UniboExample/LampExampleOntology.owl#> \
SELECT ?presence_sensor ?value \
WHERE   { \
	?presence_sensor rdf:type unibo:Sensor . \
	?presence_sensor unibo:HasValue ?value . \
	FILTER ( ?value  = "True")\
        } '

# CALLBACK
class Agent_TurnLampOn():

	    def __init__(self, SEP = None):
		self.SEP=SEP
		# self.agent_context= []

	    def handle(self, added, removed):

		# Processing..

		# Update context
		# self.agent_context= update_sparql_context (self.agent_context, added, removed)


		insert_str = ""
		delete_str = ""
		where_str  = ""

		print "\n\nSparql Subscription Indication TurnLampOn:"

		for result in added:
			id_ = None
			for bind in result:
				if bind[0] == "presence_sensor":
					if "http://www.UniboExample/LampExampleOntology.owl#PresenceSensor_" in bind[2] :
						id_=str(bind[2]).replace("http://www.UniboExample/LampExampleOntology.owl#PresenceSensor_","") 

			if id_:			
				insert_str = insert_str + '\
				unibo:LampActuator_'+ id_ +' unibo:HasValue "True" . \
				unibo:LampActuator_'+ id_ +' unibo:HasSIBTimestamp ?time_turning_on . \
				'
				delete_str = delete_str + '\
				unibo:LampActuator_'+ id_ +' unibo:HasValue "False" . \
				unibo:LampActuator_'+ id_ +' unibo:HasSIBTimestamp ?timestamp_lamp . \
				'
				where_str  = where_str + '\
				unibo:LampActuator_'+ id_ +' unibo:HasValue "False" . \
				unibo:LampActuator_'+ id_ +' unibo:HasSIBTimestamp ?timestamp_lamp . \
				'


		'''
		for results in removed:
			print "Removed"
			for result in results:
				print result
		print "\n"
		'''

		# SPARQL UPDATE

		if insert_str != "" and delete_str != "" and where_str  != "" :

			update_sparql_in='\
			PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#> \
			PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> \
			PREFIX owl:<http://www.w3.org/2002/07/owl#> \
			PREFIX xsd:<http://www.w3.org/2001/XMLSchema#> \
			PREFIX unibo:<http://www.UniboExample/LampExampleOntology.owl#> \
			INSERT  { '+ insert_str +' \
				} \
			DELETE  { '+ delete_str +' \
				} \
			WHERE   { '+ where_str  +' \
				BIND (get_sib_time() AS ?time_turning_on) \
				} '

			self.SEP.load_update_sparql(update_sparql_in)


######### AGENT II "turn lamps off"
# CONTEXT "Detect lamps on"

context_II= '\
PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#> \
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> \
PREFIX owl:<http://www.w3.org/2002/07/owl#> \
PREFIX xsd:<http://www.w3.org/2001/XMLSchema#> \
PREFIX unibo:<http://www.UniboExample/LampExampleOntology.owl#> \
SELECT ?presence_sensor ?value ?timestamp \
WHERE   { \
	?presence_sensor rdf:type unibo:Sensor . \
	?presence_sensor unibo:HasValue ?value . \
	?presence_sensor unibo:HasSIBTimestamp ?timestamp . \
        FILTER ( ?value  = "False")\
        }'


# CALLBACK "Detect lamps on"
class Agent_TurnLampOff():

	    def __init__(self, SEP = None):
		self.SEP=SEP

		# status variables
		# self.agent_context= []


	    def handle(self, added, removed):

		# Processing..

		# Update context
		# self.agent_context= update_sparql_context (self.agent_context, added, removed)

		self.sensor_ids_timestamps = []

		insert_str = ""
		delete_str = ""
		where_str  = ""

		print "\n\nSparql Subscription Agent_TurnLampOff:"

		for result in added:
			id_ = None
			timestamp_sens = None

			for bind in result:
				if bind[0] == "presence_sensor":
					if "http://www.UniboExample/LampExampleOntology.owl#PresenceSensor_" in bind[2] :
						id_=str(bind[2]).replace("http://www.UniboExample/LampExampleOntology.owl#PresenceSensor_","") 
					
				if bind[0] == "timestamp":
					timestamp_sens=bind[2]
		

			if id_ and timestamp_sens:

				insert_str = insert_str + '\
				unibo:LampActuator_'+ id_ +' unibo:HasValue "False" . \
				unibo:LampActuator_'+ id_ +' unibo:HasSIBTimestamp ?time_turning_off . \
				'
				delete_str = delete_str + '\
				unibo:LampActuator_'+ id_ +' unibo:HasValue "True" . \
				unibo:LampActuator_'+ id_ +' unibo:HasSIBTimestamp ?timestamp_lamp . \
				'
				where_str  = where_str + '\
				unibo:PresenceSensor_'+ id_ +' unibo:HasValue "False" . \
				unibo:PresenceSensor_'+ id_ +' unibo:HasSIBTimestamp "' + timestamp_sens+ '" . \
				\
				unibo:LampActuator_'+ id_ +' unibo:HasValue "True" . \
				unibo:LampActuator_'+ id_ +' unibo:HasSIBTimestamp ?timestamp_lamp . \
				'	


		# SPARQL UPDATE
		if insert_str != "" and delete_str != "" and where_str  != "" :

			update_sparql_in='\
			PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#> \
			PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> \
			PREFIX owl:<http://www.w3.org/2002/07/owl#> \
			PREFIX xsd:<http://www.w3.org/2001/XMLSchema#> \
			PREFIX unibo:<http://www.UniboExample/LampExampleOntology.owl#> \
			INSERT  { '+ insert_str +' \
				} \
			DELETE  { '+ delete_str +' \
				} \
			WHERE   { '+ where_str  +' \
				BIND (get_sib_time() AS ?time_turning_off) \
				} '

			#print update_sparql_in
			#DELAYED OF 10 SECONDS ;)
			delay = 10 
			self.SEP.load_update_sparql(update_sparql_in, float (timestamp_sens) + delay)


####################### EXECUTION ############################################

print "Loading: \n\n"
SEP =  m3_kp_api(PrintDebug = False,  IP="127.0.0.1", port=10010)

#Generate an handler first
handler_sparql_subscribe=Agent_TurnLampOn(SEP)
sparql_sub=SEP.load_subscribe_sparql(context_I, handler_sparql_subscribe)

#Generate an handler first
handler_sparql_subscribe2=Agent_TurnLampOff(SEP)
sparql_sub2=SEP.load_subscribe_sparql(context_II, handler_sparql_subscribe2)



