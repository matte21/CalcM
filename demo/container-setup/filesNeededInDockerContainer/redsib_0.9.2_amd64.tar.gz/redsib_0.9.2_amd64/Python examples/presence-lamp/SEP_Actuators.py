import sys
from smart_m3.m3_kp_api import *
import uuid
import datetime
import os
import argparse
from time import time
from time import sleep
import random


context_I= '\
PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#> \
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> \
PREFIX owl:<http://www.w3.org/2002/07/owl#> \
PREFIX xsd:<http://www.w3.org/2001/XMLSchema#> \
PREFIX unibo:<http://www.UniboExample/LampExampleOntology.owl#> \
SELECT ?value ?timestamp_lamp\
WHERE   { \
	unibo:LampActuator_1 unibo:HasValue ?value . \
	unibo:LampActuator_1 unibo:HasSIBTimestamp ?timestamp_lamp . \
        }'



class Agent_LampGateway():

	    def __init__(self, SEP = None):
		self.SEP=SEP

		#status variables
		self.timestamp_sensor = None

	    def query_handle (self, first_result):
		self.agent_context=first_result

		print "Initial Context"
		for res in first_result:
			for result in res:
				if result[0] == "value":
					print "VALUE -> " + result[2]

	    def handle(self, added, removed):

		# Processing..

		# Update context
		# self.agent_context= update_sparql_context (self.agent_context, added, removed)

		print "\n\nSparql Subscription Indication:"

		
		for results in added:
			for result in results:
				if result[0] == "value":
					print "VALUE -> " + result[2]


################################################

print "Loading: \n\n"
SEP =  m3_kp_api(PrintDebug = False,  IP="127.0.0.1", port=10010)

#Generate an handler first
handler_sparql_subscribe=Agent_LampGateway(SEP)
sparql_sub=SEP.load_subscribe_sparql(context_I, handler_sparql_subscribe)
