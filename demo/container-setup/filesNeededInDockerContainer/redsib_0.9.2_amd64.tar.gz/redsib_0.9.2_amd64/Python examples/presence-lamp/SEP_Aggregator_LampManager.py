import sys
from smart_m3.m3_kp_api import *
import uuid
import datetime
import os
import argparse
from time import time
from time import sleep
import random

############################## AGENTS ###############################

######### AGENT I
# CONTEXT

context_I= '\
PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#> \
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> \
PREFIX owl:<http://www.w3.org/2002/07/owl#> \
PREFIX xsd:<http://www.w3.org/2001/XMLSchema#> \
PREFIX unibo:<http://www.UniboExample/LampExampleOntology.owl#> \
SELECT ?value \
WHERE   { \
	unibo:PresenceSensor_1 rdf:type unibo:Sensor . \
	unibo:PresenceSensor_1 unibo:HasValue ?value . \
	FILTER ( ?value  = "True")\
        } '

# CALLBACK
class Agent_TurnLampOn():

	    def __init__(self, SEP = None):
		self.SEP=SEP

		# status variables
		# self.agent_context = []

	    def handle(self, added, removed):

		# Processing..

		# Update context
		
		# self.agent_context= update_sparql_context (self.agent_context, added, removed)


		if added != []:

			print "\n\nSparql Subscription Indication TurnLampOn:"

			update_sparql_in='\
			PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#> \
			PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> \
			PREFIX owl:<http://www.w3.org/2002/07/owl#> \
			PREFIX xsd:<http://www.w3.org/2001/XMLSchema#> \
			PREFIX unibo:<http://www.UniboExample/LampExampleOntology.owl#> \
			INSERT  { \
				unibo:LampActuator_1 unibo:HasValue "True" . \
				unibo:LampActuator_1 unibo:HasSIBTimestamp ?time_turning_on . \
				} \
			DELETE  { \
				unibo:LampActuator_1 unibo:HasValue "False" . \
				unibo:LampActuator_1 unibo:HasSIBTimestamp ?timestamp_lamp . \
				} \
			WHERE   { \
				unibo:LampActuator_1 unibo:HasValue "False" . \
				unibo:LampActuator_1 unibo:HasSIBTimestamp ?timestamp_lamp . \
				BIND (get_sib_time() AS ?time_turning_on) \
				}' 			
			self.SEP.load_update_sparql(update_sparql_in)




######### AGENT II
# CONTEXT

context_II= '\
PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#> \
PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> \
PREFIX owl:<http://www.w3.org/2002/07/owl#> \
PREFIX xsd:<http://www.w3.org/2001/XMLSchema#> \
PREFIX unibo:<http://www.UniboExample/LampExampleOntology.owl#> \
SELECT ?value ?timestamp \
WHERE   { \
	unibo:PresenceSensor_1 rdf:type unibo:Sensor . \
	unibo:PresenceSensor_1 unibo:HasValue ?value . \
	unibo:PresenceSensor_1 unibo:HasSIBTimestamp ?timestamp . \
        FILTER ( ?value  = "False")\
        }'


# CALLBACK
class Agent_TurnLampOff():

	    def __init__(self, SEP = None):
		self.SEP=SEP

		#status variables
		#self.agent_context = []

		self.timestamp_sensor = None

	    def handle(self, added, removed):

		# Processing..

		# Update context
		# self.agent_context= update_sparql_context (self.agent_context, added, removed)
		
		
		for results in added:
			for result in results:
				if result[0] == "timestamp":

					print "\n\nSparql Subscription Agent_TurnLampOff:"
					
					self.timestamp_sensor = result[2]

					update_sparql_in='\
					PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#> \
					PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> \
					PREFIX owl:<http://www.w3.org/2002/07/owl#> \
					PREFIX xsd:<http://www.w3.org/2001/XMLSchema#> \
					PREFIX unibo:<http://www.UniboExample/LampExampleOntology.owl#> \
					INSERT  { \
						unibo:LampActuator_1 unibo:HasValue "False" . \
						unibo:LampActuator_1 unibo:HasSIBTimestamp ?time_turning_off . \
						} \
					DELETE  { \
						unibo:LampActuator_1 unibo:HasValue "True" . \
						unibo:LampActuator_1 unibo:HasSIBTimestamp ?timestamp_lamp . \
						} \
					WHERE   { \
						unibo:PresenceSensor_1 unibo:HasValue "False" . \
						unibo:PresenceSensor_1 unibo:HasSIBTimestamp "' + self.timestamp_sensor+ '" . \
						\
						unibo:LampActuator_1 unibo:HasValue "True" . \
						unibo:LampActuator_1 unibo:HasSIBTimestamp ?timestamp_lamp . \
						BIND (get_sib_time() AS ?time_turning_off) \
						}'

					# Delay of 10 seconds
					delay = 10
					self.SEP.load_update_sparql(update_sparql_in, float (self.timestamp_sensor) + delay)


####################### EXECUTION ############################################

print "Loading: \n\n"
SEP =  m3_kp_api(PrintDebug = False,  IP="127.0.0.1", port=10010)

#Generate an handler first
handler_sparql_subscribe=Agent_TurnLampOn(SEP)
sparql_sub=SEP.load_subscribe_sparql(context_I, handler_sparql_subscribe)

#Generate an handler first
handler_sparql_subscribe2=Agent_TurnLampOff(SEP)
sparql_sub2=SEP.load_subscribe_sparql(context_II, handler_sparql_subscribe2)



