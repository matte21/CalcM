import sys
from smart_m3.m3_kp_api import *
import uuid
import datetime
import os
import argparse
from time import time
from time import sleep
import random


print "Loading: \n\n"
SEP =  m3_kp_api(PrintDebug = False,  IP="127.0.0.1", port=10010)

while 1:

	presence = raw_input ("t or f : ")

	if presence == "t":
			print "presence! \n"

			update_sparql_in='\
			PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#> \
			PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> \
			PREFIX owl:<http://www.w3.org/2002/07/owl#> \
			PREFIX xsd:<http://www.w3.org/2001/XMLSchema#> \
			PREFIX unibo:<http://www.UniboExample/LampExampleOntology.owl#> \
			INSERT  { \
				unibo:PresenceSensor_1 unibo:HasValue "True" . \
				unibo:PresenceSensor_1 unibo:HasSIBTimestamp ?real_time . \
				} \
			DELETE  { \
				unibo:PresenceSensor_1 unibo:HasValue "False" . \
				unibo:PresenceSensor_1 unibo:HasSIBTimestamp ?timestamp_sens . \
				} \
			WHERE   { \
				unibo:PresenceSensor_1 unibo:HasValue "False" . \
				unibo:PresenceSensor_1 unibo:HasSIBTimestamp ?timestamp_sens . \
				BIND (get_sib_time() AS ?real_time) \
				} '
			SEP.load_update_sparql(update_sparql_in)


	if presence == "f":
			print "no presence! \n"
			update_sparql_in='\
			PREFIX rdf:<http://www.w3.org/1999/02/22-rdf-syntax-ns#> \
			PREFIX rdfs:<http://www.w3.org/2000/01/rdf-schema#> \
			PREFIX owl:<http://www.w3.org/2002/07/owl#> \
			PREFIX xsd:<http://www.w3.org/2001/XMLSchema#> \
			PREFIX unibo:<http://www.UniboExample/LampExampleOntology.owl#> \
			INSERT  { \
				unibo:PresenceSensor_1 unibo:HasValue "False" . \
				unibo:PresenceSensor_1 unibo:HasSIBTimestamp ?real_time . \
				} \
			DELETE  { \
				unibo:PresenceSensor_1 unibo:HasValue "True" . \
				unibo:PresenceSensor_1 unibo:HasSIBTimestamp ?timestamp_sens . \
				} \
			WHERE   { \
				unibo:PresenceSensor_1 unibo:HasValue "True" . \
				unibo:PresenceSensor_1 unibo:HasSIBTimestamp ?timestamp_sens . \
				BIND (get_sib_time() AS ?real_time) \
				} '
			SEP.load_update_sparql(update_sparql_in)


