EXAMPLE OF EVENT-BASED KP

Description:

A Lamp is triggered by a Sensor, if the sensor finds a presence 
the process turns on the Lamp, is the presence is not detected for 
10 seconds the Lamp is turned off.

The problem is solved using semantic agents approach.

Run: 
The SIB on 10010 localhost,
SEB initialize processes,
SEP Aggregator,
SEP Sensor and Actuator
