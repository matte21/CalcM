echo 'Check the Architecture.... '
if [ `getconf LONG_BIT` = "64" ]
then
    echo "Detected 64-bit Architecture"
    sh install_x64.sh
else
    echo "Detected 32-bit Architecture!"
    echo "Not supported anymore, compile from sources."
    echo "If you are on a Raspberry check the included folder."
fi

