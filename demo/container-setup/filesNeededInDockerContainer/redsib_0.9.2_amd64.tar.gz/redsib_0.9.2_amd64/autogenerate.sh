cd sources
for i in `ls -d */`
do
	cd  $i
	echo $i # replace with actions to be done
	./autogen.sh
	dpkg-buildpackage
	cd ..
	rm *.dsc
	rm *.changes
done
cd ..

echo 'Check the Architecture.... '
if [ `getconf LONG_BIT` = "64" ]
then
    echo "Detected 64-bit Architecture"
    mkdir deb_amd64
    mv ./sources/*.deb ./deb_amd64
    #mv *.tar.gz ./sources
else
    echo "Detected 32-bit Architecture"
    mkdir deb_x86
    mv ./sources/*.deb ./deb_x86
    #mv *.tar.gz ./sources
fi
