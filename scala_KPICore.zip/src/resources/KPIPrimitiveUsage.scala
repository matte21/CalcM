package resources

import sofia_kp.scala._;

//This file explains basic information about scala KPI usage
object KPIPrimitiveUsage {
	def main(args:Array[String]) = new KPIPrimitiveUsage().testPrimitives();
}
class KPIPrimitiveUsage(sibHost:String,sibPort:Int,smartSpaceName:String){
	//SIB constants, to be opportunely modified to interact with the SIB
	def this() = this("127.0.0.1",10010,"X");
	
	//create an interface with the SIB
	val sib=new KPICore(sibHost,sibPort,smartSpaceName);
	
	//create a namespace manager to convert namespaces into their prefixes and viceversa
	val ns=new NamespaceManager("ns"->"http://examplens#");
	
	def testPrimitives(){
		//to view debug informations
		//sib.enableDebugMessage();
		//sib.enableErrorMessage();
		
		//always join before doing any other operation
		testJoin();
		
		//clean the SIB
		sib.remove((null,null,null,"uri","uri"));
		
		testInsertRDF();
		testRemoveRDF();
		testUpdateRDF();
		testUpdateSparql();
		testQueryRDF();
		testQuerySparql();
		
		//This functionality works only with osgiSIB v3 or newer
		testPersistentUpdate();
		
		/* Subscription: we can implement directly the KPICSubscribeHandler or use the DefaultKPICSubscribeHandler and set handlers only for some types of events.
		 * There are two kinds of subscription: RDF-M3 and SPARQL.*/
		testSubscribeRDF();
		testSubscribeSparql();
		
		//we can invoke unsubscribe with a single subscription ID, or without parameters to unsubscribe from all active subscriptions
		sib.unsubscribe();
		
		//remember to leave before closing the application!
		println("Disconnetting from the SIB")
		sib.leave();	//The leave operation causes the unsubscription from all pending subscriptions
	}
	
	def testJoin(){
		println(s"""Connecting to "$smartSpaceName"@$sibHost:$sibPort""");
		val r=sib.join();
		if (r isConfirmed)
			System.out.println("SIB joined correctly");
		else
			System.err.println("Error joining the SIB");
	}
	
	def testInsertRDF(){
		//we can write triples with short namespace (st ns:) and use the NamespaceManager to convert them in the correct form
		val triples=(1 to 5).map(n=>(("ns:subject_"+n,"ns:predicate_"+n,"ns:object_"+n,"uri","uri")));
		val r=sib.insert(ns.qnameToURI(triples));
		if (r isConfirmed)
			System.out.println("triples inserted into the SIB");
		else
			System.err.println("Error inserting into the SIB");
	}
	def testRemoveRDF(){
		if (sib.insert(ns.qnameToURI(("ns:subj_r","ns:pred_r","ns:obj_r","uri","uri"),("ns:subj_r","ns:pred_r","ns:obj_r2","uri","uri"))) isConfirmed){
			//the wildcard null (or SSAPXmlTools.ANYURI) match any possible value; the NamespaceManager ignores URI already full
			val r=sib.remove(ns.qnameToURI(("ns:subj_r","ns:pred_r",null,"uri","uri")));
			if (r isConfirmed)
				System.out.println("triples removed from the SIB");
			else
				System.err.println("Error removing from the SIB");
		}
	}
	
	def testUpdateRDF(){
		if (sib.insert(ns.qnameToURI(("ns:subj_old","ns:pred_old","ns:obj_old","uri","uri"))) isConfirmed){
			//update perform a remove and an insert operation with an atomic interaction
			val r=sib.update(ns.qnameToURI(("ns:subj_new","ns:pred_new","ns:obj_new","uri","uri")),
							ns.qnameToURI(("ns:subj_old","ns:pred_old","ns:obj_old","uri","uri")));
			if (r isConfirmed)
				System.out.println("triples updated on the SIB");
			else
				System.err.println("Error updating on the SIB");
		}
	}
	
	def testUpdateSparql(){
		//if we use URIs in the query, we can construct the PREFIX clause using the NamespaceManager
		var r=sib.updateSparql(ns.sparqlPrefix("ns")+"insert data {ns:subj_2 ns:pred_2 ns:obj_2, ns:obj2_2}");
		if (r isConfirmed)
			System.out.println("triples inserted into the SIB");
		else
			System.err.println("Error inserting into the SIB");
		
		r=sib.updateSparql(ns.sparqlPrefix("ns")+"delete {?s ns:pred_2 ?o} where {?s ns:pred_2 ns:obj_2, ?o}");
		if (r isConfirmed)
			System.out.println("triples removed from the SIB");
		else
			System.err.println("Error removing from the SIB");
	}
	
	def testQueryRDF(){
		/*The query RDF-M3 is based on triple patterns, it accepts one or more triple patterns and returns all the existing triples matching the patterns.
		 * Let's read all triples in the SIB */
		val r=sib.queryRDF((null,null,null,"uri","uri"));
		if (r isConfirmed)
			System.out.println("Triples found: "+ns.URIToQname(r.queryResults));
		else
			System.err.println("Error during RDF-M3 query");
	}
	
	def testQuerySparql(){
		//The SPARQL query primitive is based on a SPARQL query and the result is wrapped in an object.
		val r=sib.querySparql("select ?s ?p ?o where {?s ?p ?o}");
		if (r isConfirmed)
			System.out.println("Query results:\n"+r.sparqlQueryResults);
		else
			System.err.println("Error during SPARQL query");
	}
	
	def testSubscribeRDF(){
		/* The subscription RDF-M3 is based on triple patterns, accepts one or more triple patterns and returns all the existing triples matching the patterns. 
		 * A notification is received when triples matching one or more of the patterns are inserted (new triples) or removed (old triples). When we defines a 
		 * list of patterns the notification is received when only one pattern matches with the inserted (or removed) triple.
		 * 
		 * If we implement directly KPICSubscribeHandler, the notification logic has to be put in the override method kpicRDFEventHandler.
		 * If we use DefaultKPICSubscribeHandler, the notification logic function has to be assigned to onUpdateRDF property.
		 * 
		 * Like in removal, null and SSAP_XMLTools.ANYURI are wildcards. */
		val r=sib.subscribeRDF(new DefaultKPICSubscribeHandler {
			onUpdateRDF=(newTriples,oldTriples,indSequence,subID)=>println(s"New triples: "+ns.URIToQname(newTriples)+"\nOld triples: "+ns.URIToQname(oldTriples))
		},(null,null,null,"uri","uri"));
		if (r isConfirmed)
			System.out.println("RDF subscription confirmed: ID = "+r.subscriptionID);
		else
			System.err.println("Error during subscription");
		sib.insert(ns.qnameToURI(("ns:subj_sub1","ns:pred_sub1","ns:obj_sub1","uri","uri")));
		
		//wait for SIB notification
		Thread.sleep(1000);
	}
	
	def testSubscribeSparql(){
		/* The SPARQL subscription is based on SPARQL queries, the subscription returns all the results matching the query (like a query to SIB) then a 
		 * notification is received when the results of the query change. Only the new or old results are sent back in notifications.
		 * 
		 * If we implement directly KPICSubscribeHandler, the notification logic has to be put in the override method kpicSparqlEventHandler.
		 * If we use DefaultKPICSubscribeHandler, the notification logic function has to be assigned to onUpdateSparql property. */
		val r=sib.subscribeSparql("select ?s ?p ?o where {?s ?p ?o}",new DefaultKPICSubscribeHandler {
			onUpdateSparql=(newResults,oldResults,indSequence,subID)=>println(s"New results: "+newResults.results.map(_.map(_.uriValueShortNS(ns)))+"\nOld results: "+newResults.results.map(_.map(_.uriValueShortNS(ns))))
		});
		if (r isConfirmed){
			System.out.println("SPARQL subscription confirmed: ID = "+r.subscriptionID);
			//r contains also results that match the query at the moment of the subscription
			System.out.println("Respose to SPARQL subscription:");
			System.out.println(r.sparqlQueryResults);
		} else
			System.err.println("Error during subscription");
		sib.updateSparql(ns.sparqlPrefix("ns")+"insert data {ns:subj_sub2 ns:pred_sub2 ns:obj_sub2, ns:obj2_sub2}");
		
		//wait for SIB notification
		Thread.sleep(1000);
	}
	
	def testPersistentUpdate(){
		/* Persistent update behaves like a rule: another triple that specifies that the subject (?a) hasPredicate the predicate inserted (?b)
		 * The persistent update, when confirmed is identified by an ID that can be used to cancel it.
		 * 
		 * Works only with osgiSIB v3 or newer */
		println("inserting rule: \"Insert { ?a <http://examplens#hasPredicate> ?b } where { ?a ?b ?c }\"");
		val r=sib.persistentUpdate(ns.sparqlPrefix("ns")+"insert { ?a <http://examplens#hasPredicate> ?b } where { ?a ?b ?c }");
		val id=r.updateID;
		println("Rule inserted, rule ID="+id);
		
		// Now, if we are going to insert the following triple,
		sib.insert((ns("ns")+"subject_a","http://ns#predicate_b1","http://ns#object_c","URI","URI"));
		println(sib.queryRDF((ns("ns")+"subject_a",null,null,"URI","URI")).queryResults);
		
		// For deleting a persistent update we can use the following method
		sib.cancelPersistentUpdate(id);
	}
}