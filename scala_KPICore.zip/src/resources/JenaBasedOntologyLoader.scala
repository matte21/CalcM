package resources;

import org.apache.jena.ontology._;
import org.apache.jena.rdf.model._;
import java.io._;
import java.net._;
import java.nio.file._;
import scala.collection._;
import scala.collection.JavaConverters._;
import sofia_kp.scala._;

object JenaBasedOntologyLoader {
	private val MIN_PORT = 1;  
	private val MAX_PORT = 65535;
	def main(args:Array[String]){
		if (args.length != 4)
			printUsageAndExit();
		
		val (sibHost, portNbr, ssName, ontologyURL) = (args(0), validateSibPortNumber(args(1)), args(2), validateURL(args(3)));
		new JenaBasedOntologyLoader(sibHost, portNbr, ssName, ontologyURL).loadOntologyIntoSIB();
	}
	
	private def validateSibPortNumber(port:String) = {
		try {
			val sibPort = port toInt;
			if (sibPort < MIN_PORT || sibPort > MAX_PORT) {
				System.err.println("Port number must be within " + MIN_PORT + " and " + MAX_PORT);
				printUsageAndExit();
			}
			sibPort;
		} catch {
		case e:NumberFormatException =>
			System.err.println("The SIB port argument must be an integer");
			printUsageAndExit();
			-1;	//this shouldn't be reached
		}
	}
	
	private def validateURL(ontologyURL:String) = {
		try {
			new URL(ontologyURL);
		} catch {
		case e:MalformedURLException =>
			val f = new File(ontologyURL);
			if (!(f exists)){
				System.err.println("Ontology file does not exist");
				printUsageAndExit();
			}
			f.toURI.toURL;
		}
	}
	
	private def printUsageAndExit(){
			println("Usage:			<SIB IP/host name> <SIB port> <SS Name> <Ontology path/URL>");
			System.exit(1);
	}
}

/**This class works with jena libraries correctly imported into namespace. Libraries are not directly included
 * for reasosns of dimension and because of restrictions on directly including Jena liraries into external projects.
 * Jena libraries can be downloaded from the official Jena libraries website
 * @author Alfredo D'Elia, Riccardo Buscaroli */
class JenaBasedOntologyLoader(sibHost:String, sibPort:Int, sibNameSpace:String, ontologyPath:URL){

	def loadOntologyIntoSIB(ontologyPath:URL){
		val model = ModelFactory.createOntologyModel();
		model.read(ontologyPath toExternalForm);
		val (literalStatements, objectStatements) = model.listStatements().toList.asScala.partition(_.getObject isLiteral);
		val literalTriples = literalStatements.map(st => (st.getSubject.getURI, st.getPredicate.getURI, st.getObject.asLiteral.getString, "uri", "literal"));
		val objectTriples = objectStatements.map(st => (st.getSubject.getURI, st.getPredicate.getURI, st.getObject.asResource.getURI, "uri", "uri"));
		println(if (bufferedInsert(objectTriples ++ literalTriples)) "Ontology correctly inserted" else "Ontology not inserted");
	}
	
	def loadOntologyIntoSIB():Unit = loadOntologyIntoSIB(ontologyPath);
	
	/**Problem with this method: If inserting a triple fails, there's no cleanup as for the triples
	 * that were already inserted, AKA only a part of the ontology is loaded.
	 * This could happen, for instance, if there were more than 100 triples to insert. The first
	 * 100 triples would be successfully inserted, while the second group would not (i.e. resp.isConfirmed() 
	 * returns false.*/
	def bufferedInsert(triples:scala.collection.Seq[(String,String,String,String,String)]):Boolean = {
		val kp = new KPICore(sibHost, sibPort, sibNameSpace);
		kp.join();
		for (t <- triples grouped 100){
			val resp = kp.insert(t);
			if (!(resp isConfirmed))
				return false;
		}
		return true;	
	}
}