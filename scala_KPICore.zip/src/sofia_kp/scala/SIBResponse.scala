package sofia_kp.scala

import java.io._;
import java.nio.charset._;
import java.util._;
import scala.collection.JavaConverters._;
import scala.collection.mutable.Buffer;

import org.jdom2._;
import org.jdom2.input._;

object SIBResponse {
	private def loadXMLFromString(xml:String) = new SAXBuilder().build(new ByteArrayInputStream(xml.getBytes(Charset.forName("UTF-8"))));
}

class SIBResponse private(isXml:Boolean, param:String*){
	val (message, messageType, transactionType, status, transactionID, nodeID, spaceID, triplesEncoding, subscriptionID, updateID, indicationSequence, newResults, obsoleteResults, queryResults, sparqlQueryResults, sparqlIndNewResults, sparqlIndOldResults, rdfXmlGraph, rdfXmlRemoveGraph, queryType) = {
		var (message, messageType, transactionType, status, transactionID, nodeID, spaceID, triplesEncoding, subscriptionID, updateID, indicationSequence, newResults, obsoleteResults, queryResults, sparqlQueryResults, sparqlIndNewResults, sparqlIndOldResults, rdfXmlGraph, rdfXmlRemoveGraph, queryType) = 
			("", "", "", "", "", "", "", "", "", "", "", Nil:Seq[(String,String,String,String,String)], Nil:Seq[(String,String,String,String,String)], Nil:Seq[(String,String,String,String,String)], null:SSAPSparqlResponse, null:SSAPSparqlResponse, null:SSAPSparqlResponse, "", "", "");
		if (isXml){
			message = param(0);
			val sparql_response_document = try {
				SIBResponse.loadXMLFromString(param(0));
			} catch {
			case e:Exception =>
				e.printStackTrace();
				status = " parsing message ";
				null;
			}
	
			// GET ROOT ELEMENT
			if (sparql_response_document != null) {
				val root = sparql_response_document.getRootElement;
	
				// GET ROOT CHILDREN ()
				messageType = root.getChildText("message_type");
				transactionID = root.getChildText("transaction_id");
				transactionType = root.getChildText("transaction_id");
				nodeID = root.getChildText("node_id");
				spaceID = root.getChildText("space_id");
	
				val parToProcess = collection.mutable.Buffer[Element]();

				root.getChildren("parameter").forEach(p=>{
					p.getAttributeValue("name") match {
						case "status" =>			status = p.getText;
						case "subscription_id" =>	subscriptionID = p.getText;
						case "update_id" =>			updateID = p.getText;
						case "type" =>				queryType = p.getText;
						case "new_results" =>		parToProcess += p;
						case "obsolete_results" =>	parToProcess += p;
						case "results" =>			parToProcess += p;
						case "bnodes" =>			;
						case parName =>				System.err.println("Error while reading parameter name: " + parName);
					}
				});

				for (par <- parToProcess) {
					// System.out.println ("HIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII" + par.toString());
					val parName = par.getAttributeValue("name");
					// System.out.println("Par name to process: " + parName);
					if (par.getChild("triple_list") != null) {
						queryType = "RDF-M3";
						val triple = par.getChild("triple_list").getChildren("triple").asScala.map(etriple=>(etriple.getChild("subject").getText, etriple.getChild("predicate").getText, etriple.getChild("object").getText, "uri", etriple.getChild("object").getAttributeValue("type")));
						parName match {
							case "results" =>		queryResults = triple;
							case "new_results" =>	newResults = triple;
							case "parToProcess" =>	obsoleteResults = triple;
						}
					} else if (par.getChild("sparql", Namespace.getNamespace("http://www.w3.org/2005/sparql-results#")) != null) {
						queryType = "sparql";
						val sparql_resp = SSAPSparqlResponse.fromResponseElement(par.getChild("sparql", Namespace.getNamespace("http://www.w3.org/2005/sparql-results#")));
						if (parName.equalsIgnoreCase("results") || parName.equalsIgnoreCase("new_results") || parName.equalsIgnoreCase("parToProcess"))
							sparqlQueryResults = sparql_resp;
					}
				}
			}
		} else if (param.size == 3){
			subscriptionID = param(2);
			if (param(1) == null && param(0).equals("UNSUB")){
				messageType = "CONFIRM";
				transactionType = "UNSUBSCRIBE";
				status = "m3:unknown";
			} else
				message = param(1);
		}
		(message, messageType, transactionType, status, transactionID, nodeID, spaceID, triplesEncoding, subscriptionID, updateID, indicationSequence, newResults, obsoleteResults, queryResults, sparqlQueryResults, sparqlIndNewResults, sparqlIndOldResults, rdfXmlGraph, rdfXmlRemoveGraph, queryType);
	}
	
	def this(primitive:String, message:String, subscriptionID:String) = this(false, primitive, message, subscriptionID);

	def this(xml:String) = this(true, xml);
	
	override def toString() = message;

	/**This method checks if operations is confirmed.<br>
	 * <b>NOTE:</b> for <b>unsubscribe</b> returns always true.
	 * 
	 * @return <b>true</b> if operation is confirmed<br>
	 * 		<b>false</b> if operation fails
	 */
	def isConfirmed() = (transactionType != null && transactionType.equalsIgnoreCase("unsubscribe")) || status.equalsIgnoreCase("m3:success");
}
