package sofia_kp.scala

import java.io._;
import java.net._;
import scala.io._;

class Subscription(kpSocket:Socket, eh:KPICSubscribeHandler){
	private var stopped = false;
	{
		System.out.println("Subscription: going to start thread");

		val eventThread = new Thread(()=>{
			val xmlTools = new SSAPXMLTools(null, null, null);
			var (msgEvent, restOfTheMessage) = ("", "");
			val buffsize = 4 * 1024;
			val buffer = new Array[Char](buffsize);
			val builder = new StringBuilder();
			var charRead = 0;
			try {
				val in = new BufferedReader(new InputStreamReader(kpSocket.getInputStream))
				charRead = in.read(buffer, 0, buffer.length);
				while (!stopped && (charRead != -1 || !(restOfTheMessage isEmpty))){
					if (restOfTheMessage != ""){
						builder ++= restOfTheMessage;
						restOfTheMessage = "";
					}
					if (charRead != -1)
						builder ++= buffer.subSequence(0, charRead).toString;
					restOfTheMessage = builder toString;
					if ((restOfTheMessage contains "<SSAP_message>") && (restOfTheMessage contains "</SSAP_message>")){
						// One or more messages in the same notification
						val index = restOfTheMessage.indexOf("</SSAP_message>") + 15;
						msgEvent = restOfTheMessage.substring(0, index);
						restOfTheMessage = restOfTheMessage.substring(index);
						// System.out.println("indication: " + msg_event);
						val subID = xmlTools.getSubscriptionID(msgEvent);
	
						// here it starts single message processing and it's possible to launch multiple threads for parallelization
						if (xmlTools.isUnsubscriptionConfirmed(msgEvent)){
							eh.kpicUnsubscribeEventHandler(subID);
							//restOfTheMessage = "";
						} else {
							val indSequence = xmlTools.getSSAPMsgIndicationSequence(msgEvent);
							if (xmlTools.isRDFNotification(msgEvent)) {
								val triplesN = xmlTools.getNewResultEventTriple(msgEvent);
								val triplesO = xmlTools.getObsoleteResultEventTriple(msgEvent);
								// int indSequence = xmlTools.getSSAPmsgIndicationSequence(msgEvent);
								eh.kpicRDFEventHandler(triplesN, triplesO, indSequence, subID);
							} else {
								// System.out.println("Notif. " + indSequence + " id = " + id +"\n");
								val respNew = xmlTools.getSparqlIndicationNewResults(msgEvent);
								val respOld = xmlTools.getSparqlIndicationObsoleteResults(msgEvent);
	
								eh.kpicSparqlEventHandler(respNew, respOld, indSequence, subID);
								// if (respNew != null)
								// println("new: \n " + respNew);
								// if (respOld != null)
								// println("obsolete: \n " + respOld);
							}
	
							if ((restOfTheMessage contains "<SSAP_message>") && (restOfTheMessage contains "</SSAP_message>")) {
								// a complete message in the rest of the message
								// deb_print("KpCore:EventHandlerThread:YES,UnSubscription Confirmed!\n"+"EVENT HANDLER THREAD:stop");
								// println( "Rest of the message= " + restOfTheMessage);
								val test = restOfTheMessage.substring(0, restOfTheMessage.indexOf("</SSAP_message>") + 15);
								if (xmlTools.isUnsubscriptionConfirmed(test)) {
									// println("I should never print this please check an unsubscription in the rest of the message");
									eh.kpicUnsubscribeEventHandler(subID);
									stop();
									//restOfTheMessage = "";
								}
							}
						}
						charRead = 0;
						msgEvent = "";
						builder.length = 0;
					}
					if (!stopped)
						charRead=in.read(buffer,0,buffer.length);
				// else if( msg_event.contains("</SSAP_message>"))
				// deb_print("***NOT YET RECOGNIZED EVENT MESSAGE:_"+msg_event.replace("\n", "")+"_");
				}
				//if (restOfTheMessage == "" && stopped)	//XXX
				try {
					System.out.println("I should not go here until I unsubscribe");
					kpSocket.close();
				} catch {
				case e:Exception =>
					// err_print("KpCore:startEventHandlerThread:closing
					// connection:Exception:\n"+e);
					e.printStackTrace();
					eh.kpicExceptionEventHandler(e);
					// this.ERR_EXC_CLOSE_CONN;
				}
			} catch {
			case e:Exception =>
				// err_print("KpCore:startEventHandlerThread:reading:Exception:\n"+e);
				e.printStackTrace();
				eh.kpicExceptionEventHandler(e);
			}
		}).start();
	}
	def stop() = stopped = true;
}
