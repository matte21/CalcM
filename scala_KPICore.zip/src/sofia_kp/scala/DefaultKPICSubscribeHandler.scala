package sofia_kp.scala

/**This is a default implementation of the KPICSubscribeHandler
 * @author Riccardo Buscaroli */
class DefaultKPICSubscribeHandler extends KPICSubscribeHandler {
	var onUpdateRDF = (newTriples:Seq[(String,String,String,String,String)], oldTriples:Seq[(String,String,String,String,String)], indSequence:String, subID:String) => {};
	var onUpdateSparql = (newResults:SSAPSparqlResponse, oldResults:SSAPSparqlResponse, indSequence:String, subID:String) => {};
	var onUnsubscribe = (subID:String) => {};
	var onException = (socketException:Throwable) => {};
	
	override def kpicRDFEventHandler(newTriples:Seq[(String,String,String,String,String)], oldTriples:Seq[(String,String,String,String,String)], indSequence:String, subID:String) = onUpdateRDF(newTriples, oldTriples, indSequence, subID);
	override def kpicSparqlEventHandler(newResults:SSAPSparqlResponse, oldResults:SSAPSparqlResponse, indSequence:String, subID:String) = onUpdateSparql(newResults, oldResults, indSequence, subID);
	override def kpicUnsubscribeEventHandler(subID:String) = onUnsubscribe(subID);
	override def kpicExceptionEventHandler(socketException:Throwable) = onException(socketException);
}