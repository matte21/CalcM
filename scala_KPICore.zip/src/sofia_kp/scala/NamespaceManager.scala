package sofia_kp.scala

import java.io._;
import org.jdom2.input._;
import scala.collection._;

/**This class contains helpful methods to manage namespaces in RDF and SPARQL operations
 * @author Riccardo Buscaroli */
class NamespaceManager(namespaceMapEntries:(String,String)*){
	private val ns = mutable.Map[String,String](namespaceMapEntries:_*);
	def this(namespaceMap:Map[String, String]){
		this();
		loadNamespaces(namespaceMap);
	}
	def this(xml:File){
		this();
		loadNamespaces(xml);
	}
	def this(xml:String){
		this();
		loadNamespaces(xml);
	}
	def this(in:InputStream){
		this();
		loadNamespaces(in);
	}
	
	/**@param xml	a RDF/XML document from which load namespaces */
	def loadNamespaces(xml:File){
		try {
			loadNamespaces(new FileInputStream(xml));
		} catch {
			case e:FileNotFoundException => throw new IllegalArgumentException(e);
		}
	}
	/**@param xml	a RDF/XML document from which load namespaces */
	def ++=(xml:File):NamespaceManager = { loadNamespaces(new FileInputStream(xml)); this }
	
	/**@param xml	a RDF/XML document from which load namespaces */
	def loadNamespaces(xml:String):Unit = loadNamespaces(new ByteArrayInputStream(xml.getBytes));
	/**@param xml	a RDF/XML document from which load namespaces */
	def ++=(xml:String):NamespaceManager = { loadNamespaces(new ByteArrayInputStream(xml.getBytes)); this }

	/**@param in	a RDF/XML document from which load namespaces */
	def loadNamespaces(in:InputStream):Unit = new SAXBuilder().build(in).getRootElement.getNamespacesInScope.forEach(n => ns(n.getPrefix) = n.getURI);
	/**@param in	a RDF/XML document from which load namespaces */
	def ++=(in:InputStream):NamespaceManager = { loadNamespaces(in); this }
	
	/**@param map	a prefix->namespace map */
	def loadNamespaces(map:Map[String, String]):Unit = ns ++= map;
	/**@param map	a prefix->namespace map to add */
	def ++=(map:Map[String, String]):NamespaceManager = { ns ++= map; this }
	
	/**@param map	a prefix->namespace sequence */
	def loadNamespaces(map:(String, String)*):Unit = ns ++= map;
	/**@param map	a prefix->namespace sequence to add */
	def ++=(map:(String, String)*):NamespaceManager = { ns ++= map; this }
	
	/**@param map	a prefix->namespace entry to add */
	def +=(ns:(String, String)):NamespaceManager = { this.ns += ns; this }
	
	/**@return the full namespace, or an empty string if the prefix is unknown */
	def fullNamepace(prefix:String) = ns.getOrElse(prefix,"");
	/**@return the full namespace
	 * @throws NoSuchElementException if the prefix is unknown */
	def apply(prefix:String) = ns(prefix);
	
	/**Map of known namespaces */
	def namespaces = ns toMap;
	
	/**Replace the prefix with the full namespace */
	def fullURI(s:String) = {
		if (s == null)
			null;
		else if (s.indexOf(':') <= 0)
			s;
		else {
			val uri = s.split(":",2);
			val fullNS = ns(uri(0));
			if (fullNS != null)
				fullNS + uri(1);
			else
				throw new IllegalArgumentException(uri(0) + ": unknown namespace");
		}
	}
	
	/**Replace the full namespace with prefix */
	def shortURI(uri:String) = {
		val nsl = ns.filter(uri startsWith _._2);
		if (nsl isEmpty)
			uri
		else {
			val ns = nsl.maxBy(_._2.length);
			ns._1 + ":" + uri.substring(ns._2.length);
		}
	}
	
	/**Removes the namespace */
	def removeNamespace(uri:String) = {
		val i = uri.indexOf("#");
		if (i >= 0)	//shortcut: most namespaces ends with #
			uri.substring(i + 1);
		else {
			val nsl = ns.filter(uri startsWith _._2);
			if (nsl isEmpty)
				uri
			else
				uri.substring(nsl.maxBy(_._2.length)._2.length);
		}
	}
	
	/**Transform triple elements in the format required by RDF query.
	 * Don't use default namespaces for URI elements.
	 * @param triples	Sequence of elements; every tuple is formed by
	 *  				subject, predicate, object, subject type and object type
	 * @return a sequence of triples */
	def triplesToFullURI(triples:Seq[(String, String, String, String, String)]) = triples.map(t => (fullURI(t._1), fullURI(t._2), if (t._5 equalsIgnoreCase "uri") fullURI(t._3) else t._3, t._4, t._5));
	/**Transform triple elements in the format required by RDF query.
	 * Don't use default namespaces for URI elements.
	 * @param triples	Sequence of elements; every tuple is formed by
	 *  				subject, predicate, object, subject type and object type
	 * @return a sequence of triples */
	def triplesToFullURI(triple:(String, String, String, String, String), triples:(String, String, String, String, String)*):Seq[(String, String, String, String, String)] = triplesToFullURI(triple +: triples);
	
	/**Transform back triple elements from the format required by RDF query.
	 * @param triples	Sequence of elements; every tuple is formed by
	 *  				subject, predicate, object, subject type and object type
	 * @return a sequence of triples */
	def triplesToShortURI(triples:Seq[(String, String, String, String, String)]) = triples.map(t => (shortURI(t._1), shortURI(t._2), if (t._5 equalsIgnoreCase "uri") shortURI(t._3) else t._3, t._4, t._5));
	/**Transform back triple elements from the format required by RDF query.
	 * @param triples	Sequence of elements; every tuple is formed by
	 *  				subject, predicate, object, subject type and object type
	 * @return a sequence of triples */
	def triplesToShortURI(triple:(String, String, String, String, String), triples:(String, String, String, String, String)*):Seq[(String, String, String, String, String)] = triplesToShortURI(triple +: triples);
	
	/**Transform back triple elements from the format required by RDF query
	 * and remove the namespace from URIs
	 * @param triples	Sequence of elements; every tuple is formed by
	 *  				subject, predicate, object, subject type and object type
	 * @return a sequence of triples */
	def triplesRemoveNamespace(triples:Seq[(String, String, String, String, String)]) = triples.map(t => (removeNamespace(t._1), removeNamespace(t._2), if (t._5 equalsIgnoreCase "uri") removeNamespace(t._3) else t._3, t._4, t._5));
	/**Transform back triple elements from the format required by RDF query
	 * and remove the namespace from URIs
	 * @param triples	Sequence of elements; every tuple is formed by
	 *  				subject, predicate, object, subject type and object type
	 * @return a sequence of triples */
	def triplesRemoveNamespace(triple:(String, String, String, String, String), triples:(String, String, String, String, String)*):Seq[(String, String, String, String, String)] = triplesRemoveNamespace(triple +: triples);
	
	/**Prepare the PREFIX clauses of a SPARQL query
	 * @param namespacePref - list of prefixes used in the query
	 * @return The PREFIX clauses of the query */
	def sparqlPrefix(namespacePref:String*) = namespacePref.map(p => s"PREFIX $p:<${fullNamepace(p)}>").mkString("", "\n", "\n");

}