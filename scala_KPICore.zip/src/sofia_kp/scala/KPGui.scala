package sofia_kp.scala

import java.awt._;
import java.awt.event._;
import javax.swing._;
import java.util.Properties

object KPGui {
	def main(args:Array[String]) {
		var (ip, port, ssName, s, p, o, kpID, defKpID, autoJoin, goChanges) =
			("127.0.0.1", "10010", "X", "*", "*", "*", "DEAD-BEAF", "DEAD-BEAF", "false", "false");

		println("\n**************************************************");
		println("*  Available parameters (with default values):");
		println("*      -ip " + ip);
		println("*      -port " + port);
		println("*      -ssname " + ssName);
		println("*      -s " + s);
		println("*      -p " + p);
		println("*      -o " + o);
		println("*      -kpid " + "<random UUID>");
		println("*      -autoJoin " + autoJoin + " [true|false]");
		println("**************************************************\n");
		
		for (a <- args) {
			a match {
				case "-ip" =>
					ip = a;
					goChanges = "true";
				case "-port" =>
					port = a;
					goChanges = "true";
				case "-ssname" =>
					ssName = a;
					goChanges = "true";
				case "-s" => s = a;
				case "-p" => p = a;
				case "-o" => o = a;
				case "-kpid" => kpID = a;
				case "-autoJoin" => autoJoin = a;
				case _ => println("Parameter not recognized: " + a);
			}
		}

		try {
			javax.swing.UIManager.setLookAndFeel(javax.swing.UIManager.getSystemLookAndFeelClassName)
		} catch {
			case e:Exception => ;
		}
		val kpgui = new KPGui();
		val f = new JFrame(" - SOFIA KP - ");
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		f.setSize(new Dimension(700, 200));
		f.setContentPane(kpgui); //
		// f.pack();
		f.setVisible(true);

		/* ______________________ */
		// kpgui.tfIP.setText("127.0.0.1");
		// kpgui.cbIPList.setSelectedItem("mml.arces.unibo.it");
		kpgui.tfIP.setText(ip);
		kpgui.cbIPList.setSelectedItem(ip);

		kpgui.tfPort.setText(port);
		kpgui.tfSSN.setText(ssName);

		/**
		 * / kpgui.tfSO.setText("*"); kpgui.tfPO.setText("*");
		 * kpgui.tfOO.setText("*"); /
		 **/
		kpgui.tfSN.setText(s);
		kpgui.tfPN.setText(p);
		kpgui.tfON.setText(o);
		/**/
		kpgui.tfSNType.setText("uri");
		kpgui.tfSOType.setText("uri");
		kpgui.tfONType.setText("uri");
		kpgui.tfOOType.setText("uri");
		/**/
		kpgui.tfKPID.setText(kpID);
		/* ______________________ */

		if (kpID != defKpID)
			kpgui.userKpID = kpID;
		if (goChanges == "true")
			kpgui.bGo.getActionListeners()(0).actionPerformed(null);
		if (autoJoin == "true") {
			if (goChanges != "true")
				kpgui.bGo.getActionListeners()(0).actionPerformed(null);
			kpgui.bJoin.getActionListeners()(0).actionPerformed(null);
		}

		kpgui.taMemo.append("\n**************************************************\n");
		kpgui.taMemo.append("*  KP parameters:\n");
		kpgui.taMemo.append("*      -ip " + ip + "\n");
		kpgui.taMemo.append("*      -port " + port + "\n");
		kpgui.taMemo.append("*      -ssname " + ssName + "\n");
		kpgui.taMemo.append("*      -s " + s + "\n");
		kpgui.taMemo.append("*      -p " + p + "\n");
		kpgui.taMemo.append("*      -o " + o + "\n");
		if (goChanges == "true")
			kpgui.taMemo.append("*      -kpid " + kpgui.kp.nodeID + "\n");
		kpgui.taMemo.append("**************************************************\n");
	}
}

class KPGui extends JPanel with KPICSubscribeHandler {
	private var kp = null:KPICore;
	private var userKpID = "";

	private var f1 = null:JFrame;

	private var history = new StringBuilder();

	private var	myLastSubscription = "";

	/* 0_________________________________________________________ */
	// Connection
	private val tfIP = new JTextField("");
	/*-_________________________________________________________*/

	private val SIB_IP = Array("127.0.0.1", "localhost", "mml.arces.unibo.it");
	private val SIB_PORT = Array("10010", "7701");

	/*-_________________________________________________________*/

	private val cbIPList = new JComboBox(SIB_IP);
	cbIPList.setEditable(true);

	private val cbPortList = new JComboBox(SIB_PORT);
	cbPortList.setEditable(true);
	/*-_________________________________________________________*/

	private val tfPort = new JTextField("");
	private val tfSSN = new JTextField("");

	tfIP.setColumns(10);
	tfPort.setColumns(5);
	tfSSN.setColumns(5);

	private val bGo = new JButton("INIT");
	bGo.addActionListener(_=>{
		jpMain.setLayout(new GridLayout(8, 1));
		println("ACTION:bGO");
		// println("ACTION:tfIP.getText"+tfIP.getText);
		// println("ACTION:(String)cbIPList.getSelectedItem"+(String)cbIPList.getSelectedItem);
		println("ACTION:tfPort:" + tfPort.getText);

		kp = new KPICore(cbIPList.getSelectedItem.toString, cbPortList.getSelectedItem.toString.toInt, tfSSN.getText);

		if (userKpID != "")
			kp.nodeID = userKpID;

		kp.enableDebugMessage();
		kp.enableErrorMessage();

		if (kp != null) {
			println("Loading KP interface");
			jpMain.remove(jpConnection);
			jpMain.add(jpJoinLeave);
			jpMain.add(jpTextFieldsOld);
			jpMain.add(jpConsole);
			jpMain.add(jpTextFieldsNew);
			jpMain.add(jpUpdate);
			jpMain.add(jpSparql);
			jpMain.add(jpSubscriptions);

			add(jpMemo, BorderLayout.CENTER);

			taMemo.setText("READY!");

			val w = SwingUtilities.windowForComponent(this).asInstanceOf[JFrame];
			w.setMaximumSize(((d:Dimension)=>new Dimension(d.width,d.height-40))(Toolkit.getDefaultToolkit.getScreenSize));
			w.pack();
			if (w.getHeight>w.getMaximumSize.height)
				w.setSize(w.getWidth, w.getMaximumSize.height);
			
			w.addWindowListener(new WindowListener{
			    override def windowOpened(e:WindowEvent){}
			    override def windowClosing(e:WindowEvent):Unit = kp.leave();
			    override def windowClosed(e:WindowEvent){}
			    override def windowIconified(e:WindowEvent){}
			    override def windowDeiconified(e:WindowEvent){}
			    override def windowActivated(e:WindowEvent){}
			    override def windowDeactivated(e:WindowEvent){}
			});
		}
	});

	private val jpConnection = new JPanel(false);
	jpConnection.setLayout(new GridLayout(4, 1));
	private val line1 = new JPanel(false);
	private val line2 = new JPanel(false);
	private val line3 = new JPanel(false);
	private val line4 = new JPanel(false);

	line1.add(new JLabel("IP"));
	line1.add(cbIPList);
	line1.add(new JLabel("PORT"));
	line1.add(cbPortList);
	line1.add(new JLabel("SSN"));
	line1.add(tfSSN);
	line1.add(bGo);

	jpConnection.add(line1);

	/*
	 * Components for service discovery
	 */
	// SOFIADNS_IP[0]="http://mml.arces.unibo.it/sofia.dns";
	private val SOFIADNS_IP = Array("http://mml.arces.unibo.it/sofia.service.registry");
	private val tfSerName = new JTextField("sib");
	private val bSearchRService = new JButton("Search for Service");
	bSearchRService.addActionListener(_=>{
		println("ACTION:bSearchAndGo");
		println("ACTION:tfSerName:" + tfSerName.getText);
		println("ACTION:cbSOFIADNSIPList:" + cbSOFIADNSIPList.getSelectedItem);

		val sr = new ArcesServiceRegistry(cbSOFIADNSIPList.getSelectedItem toString);
		val userServiceSearch = new Properties();

		// From, e.g. a=1&b=2&qwerty=23, to properties
		if (otherParams.getText != "")
			for (serv <- otherParams.getText.split("\\&")) {
				val param = serv.split("=");
				userServiceSearch.setProperty(param(0), param(1));	//name, value
			}

		val reg = sr.search(userServiceSearch);

		if (reg == null || reg.size == 0)
			JOptionPane.showConfirmDialog(null, "No service found!\n...try again!", "WARNING", JOptionPane.CLOSED_OPTION);
		else {
			val str_service_list = reg.mkString("", "\n", "\n");
			JOptionPane.showConfirmDialog(null, "Service found list:\n" + str_service_list + "\n", "WARNING", JOptionPane.CLOSED_OPTION);
		}
	});
	private val cbSOFIADNSIPList = new JComboBox(SOFIADNS_IP);
	cbSOFIADNSIPList.setEditable(true);

	cbSOFIADNSIPList.setSize(100, 20);
	tfSerName.setColumns(10);

	line2.add(new JLabel("SOFIA.DNS"));
	line2.add(cbSOFIADNSIPList);

	jpConnection.add(line2);

	private val otherParams = new JTextField("");
	otherParams.setColumns(40);

	line3.add(new JLabel("Service profile properties:"));
	line3.add(otherParams);
	jpConnection.add(line3);

	bSearchRService.setSize(100, 50);
	line4.add(bSearchRService);
	jpConnection.add(line4);
	/* 1_________________________________________________________ */

	private val bJoin = new JButton("Join");
	bJoin.addActionListener(_=>{
		taMemo.setText("");
		val ret = kp.join();
		taMemo.append("Sent: " + kp.xmlTools.join() + "\n");

		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "(" + kp.errID + ")\n");
		taMemo.append("Join confirmed:" + (if (kp.xmlTools.isResponseConfirmed(ret)) "YES" else "NO"));
		taMemo.append("\n*** SSAP message status:" + ret.status + "\n");
		history.append("join ip=" + kp.host + " port = " + kp.port + " SIB Nme = " + kp.smartSpaceName + "\n");

		taHistory.setText(history.toString);
	});
	private val bLeave = new JButton("Leave");
	bLeave.addActionListener(_=>{
		taMemo.setText("");
		val ret = kp.leave();
		taMemo.append("Sent: " + kp.xmlTools.leave() + "\n");

		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "(" + kp.errID + ")\n");
		taMemo.append("Leave confirmed:" + (if (kp.xmlTools.isResponseConfirmed(ret)) "YES" else "NO"));
		taMemo.append("\n*** SSAP message status:" + ret.status + "\n");
		history.append("leave ip=" + kp.host + " port = " + kp.port + " SIB Nme = " + kp.smartSpaceName + "\n");

		taHistory.setText(history.toString);
	});

	private val bViewHistory = new JButton("View Command History");
	bViewHistory.addActionListener(_=>{
		if (f1 == null || !f1.isVisible) {
			taHistory.setText("");

			f1 = new JFrame(" - GUI History - ");
			f1.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

			val jpHistory = new JPanel(false);
			jpHistory.setLayout(new GridLayout(1, 1));
			// JTextArea taHistory = new JTextArea();
			jpHistory.add(taHistory);
			val sbrText1 = new JScrollPane(taHistory);
			sbrText1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
			jpHistory.add(sbrText1);

			f1.setSize(new Dimension(900, 200));
			f1.add("Center", jpHistory);
			f1.add(jpHistory);
			// f.pack();
			f1.setVisible(true);

			// jpHistory.setLayout( new BorderLayout() );
			// jpHistory.add( jpMain, BorderLayout.SOUTH);
			taHistory.append(history.toString);
		} else {
			taHistory.setText(history.toString);
		}
	});
	// bViewHistory.setForeground(Color.);

	// Synchronization
	private val tfKPID = new JTextField("");
	tfKPID.setColumns(10);
	private val bSetKPID = new JButton("Re-Join with this KP ID");
	bSetKPID.addActionListener(_=>{
		// Before...leave the Smart Space...
		taMemo.setText("");
		var ret = kp.leave();
		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "(" + kp.errID + ")\n");
		taMemo.append("Leave confirmed:" + (if (kp.xmlTools.isResponseConfirmed(ret)) "YES" else "NO"));

		try {
			Thread.sleep(1000);
		} catch {
		case e:InterruptedException =>
			e.printStackTrace();
			Predef.print("Sleep failed:" + e + "\n");
		}

		// set the new KP ID
		kp.nodeID = tfKPID.getText;

		// Join the Smart Space taMemo.setText("");
		ret = kp.join();
		taMemo.append("Sent: " + kp.xmlTools.join() + "\n");

		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "(" + kp.errID + ")\n");
		taMemo.append("Join confirmed:" + (if (kp.xmlTools.isResponseConfirmed(ret)) "YES" else "NO"));
		taMemo.append("\n*** SSAP message status:" + ret.status + "\n");
	});
	// bSetKPID.setForeground(Color.BLUE);

	private val jpJoinLeave = new JPanel(false);
	jpJoinLeave.add(bJoin);
	jpJoinLeave.add(bLeave);

	private var labelx = new JLabel("KP ID");
	// labelx.setForeground(Color.BLUE);
	jpJoinLeave.add(labelx);
	jpJoinLeave.add(tfKPID);
	jpJoinLeave.add(bSetKPID);
	jpJoinLeave.add(bViewHistory);

	/* 2_________________________________________________________ */
	// old
	private val tfSN = new JTextField("");
	private val tfPN = new JTextField("");
	private val tfON = new JTextField("");
	private val tfSNType = new JTextField("");
	private val tfONType = new JTextField("");

	tfSN.setColumns(10);
	tfPN.setColumns(10);
	tfON.setColumns(10);
	tfSNType.setColumns(10);
	tfONType.setColumns(10);

	private val jpTextFieldsOld = new JPanel(false);
	// jpTextFieldsOld.add( new JLabel("Subject") );
	labelx = new JLabel("Subject (S)");
	// labelx.setForeground(Color.RED);
	jpTextFieldsOld.add(labelx);
	jpTextFieldsOld.add(tfSN);
	// jpTextFieldsOld.add( new JLabel("Predicate") );
	labelx = new JLabel("Predicate (S)");
	// labelx.setForeground(Color.RED);
	jpTextFieldsOld.add(labelx);

	jpTextFieldsOld.add(tfPN);
	jpTextFieldsOld.add(new JLabel("Object"));
	jpTextFieldsOld.add(tfON);
	jpTextFieldsOld.add(new JLabel("Sub Type"));
	jpTextFieldsOld.add(tfSNType);
	jpTextFieldsOld.add(new JLabel("Obj Type"));
	jpTextFieldsOld.add(tfONType);

	/* 3_________________________________________________________ */

	private val bRDFQuery = new JButton("RDF Query");
	bRDFQuery.addActionListener(_=>{
		taMemo.setText("");
		val ret = kp.queryRDF((
				if (tfSN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfSN.getText,
				if (tfPN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfPN.getText,
				if (tfON.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfON.getText,
				tfSNType.getText, tfONType.getText));
		taMemo.append("Sent: " + kp.xmlTools.queryRDF((
				if (tfSN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfSN.getText,
				if (tfPN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfPN.getText,
				if (tfON.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfON.getText,
				tfSNType.getText, tfONType.getText)) + "\n");

		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "(" + kp.errID + ")\n");
		taMemo.append("RDFQuery confirmed:" + (if (kp.xmlTools.isResponseConfirmed(ret)) "YES" else "NO") + "\n");
		taMemo.append("\n*** SSAP message status:" + ret.status + "\n");

		if (kp.xmlTools.isResponseConfirmed(ret)) {
			history.append("rdf query s = " + tfSN.getText + " p = " + tfPN.getText + " o = " + tfON.getText
					+ " ot = " + tfONType.getText + "\n");
			val triples = if (ret == null) null else ret.queryResults;
	
			if (triples != null)
				taMemo.append(triples.map(t=>s"  S:[${t._1}] P:[${t._2}] O:[${t._3}] Stype:[${t._4}] Otype:[${t._5}]").mkString("Triple List:\n", "\n", "\n"));
			taHistory.setText(history.toString);
		}
	});
	private val bInsert = new JButton("Insert");
	bInsert.addActionListener(_=>{
		taMemo.setText("");
		val ret = kp.insert((tfSN.getText, tfPN.getText, tfON.getText, tfSNType.getText, tfONType.getText));
		taMemo.append("Sent: " + kp.xmlTools.insert((tfSN.getText, tfPN.getText, tfON.getText,
				tfSNType.getText, tfONType.getText)) + "\n");

		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "(" + kp.errID + ")\n");
		taMemo.append("\n*** SSAP message status:" + ret.status + "\n");
		history.append("rdf insert s = " + tfSN.getText + " p = " + tfPN.getText + " o = " + tfON.getText
				+ " ot = " + tfONType.getText + "\n");

		taHistory.setText(history.toString);
	});
	private val bRemove = new JButton("Remove");
	bRemove.addActionListener(_=>{
		taMemo.setText("");
		val ret = kp.remove((
				if (tfSN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfSN.getText,
				if (tfPN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfPN.getText,
				if (tfON.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfON.getText,
				tfSNType.getText, tfONType.getText));
		taMemo.append("Sent: " + kp.xmlTools.remove((
				if (tfSN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfSN.getText,
				if (tfPN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfPN.getText,
				if (tfON.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfON.getText,
				tfSNType.getText, tfONType.getText)) + "\n");

		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "(" + kp.errID + ")\n");
		taMemo.append("\n*** SSAP message status:" + ret.status + "\n");
		history.append("rdf remove s = " + tfSN.getText + " p = " + tfPN.getText + " o = " + tfON.getText
				+ " ot = " + tfONType.getText + "\n");

		taHistory.setText(history.toString);
	});
	private val bSubscribe = new JButton("Subscribe");
	bSubscribe.addActionListener(_=>{
		taMemo.setText("");
		val ret = kp.subscribeRDF(this, (
				if (tfSN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfSN.getText,
				if (tfPN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfPN.getText,
				if (tfON.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfON.getText,
				tfSNType.getText, tfONType.getText));
		taMemo.append("Sent: " + kp.xmlTools.subscribeRDF((
				if (tfSN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfSN.getText,
				if (tfPN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfPN.getText,
				if (tfON.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfON.getText,
				tfSNType.getText, tfONType.getText)) + "\n");

		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "(" + kp.errID + ")\n");
		taMemo.append("Subscribe confirmed:" + (if (kp.xmlTools.isResponseConfirmed(ret)) "YES" else "NO") + "\n");
		myLastSubscription = ret.subscriptionID;
		val item = new ComboItemRenderable();
		item.name = myLastSubscription;
		item.visualize = "  s=" + tfSN.getText + "  p=" + tfPN.getText + "  o=" + tfON.getText + "  ot=" + tfONType.getText;
		cbSUB.addItem(item);
		taMemo.append("Subscribe ID:" + myLastSubscription + "\n");
		taMemo.append("\n*** SSAP message status:" + ret.status + "\n");
		history.append("rdf subscribe s = " + tfSN.getText + " p = " + tfPN.getText + " o = " + tfON.getText + " ot = " + tfONType.getText + "\n");
		if (kp.xmlTools.isResponseConfirmed(ret)) {
			history.append("rdf query s = " + tfSN.getText + " p = " + tfPN.getText + " o = " + tfON.getText + " ot = " + tfONType.getText + "\n");
			val triples = if (ret == null) null else ret.queryResults;

			if (triples != null)
				taMemo.append(triples.map(t=>s"  S:[${t._1}] P:[${t._2}] O:[${t._3}] Stype:[${t._4}] Otype:[${t._5}]").mkString("Triple List:\n", "\n", "\n"));
			taHistory.setText(history.toString);
		}
	});
	private val bUnsubscribe = new JButton("Unsubscribe");
	bUnsubscribe.addActionListener(_=>{
		taMemo.setText("");

		taMemo.append("UnSubscribe ... waiting for the SIB answer...\n");
		val item = cbSUB.getSelectedItem.asInstanceOf[ComboItemRenderable];
		val ret = kp.unsubscribe(item.name);
		taMemo.append("Sent: " + kp.xmlTools.unsubscribe(item.name) + "\n");
		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "(" + kp.errID + ")\n");

		cbSUB.removeItemAt(cbSUB.getSelectedIndex);
		// taMemo.append("SIB MESSAGE:\n"+ret+"\nKP-CORE
		// MESSAGE:"+kp.errMess+"\n");
		// taMemo.append("UnSubscribe
		// confirmed:"+(xmlTools.isUnSubscriptionConfirmed(ret)?"YES":"NO")+"\n");
		taMemo.append("...ok:" + ret + "\n");
		// taMemo.append("\n*** SSAP message
		// status:"+xmlTools.getSSAPmsgStatus(ret));
		history.append("unsubscribe " + item + "\n");

		taHistory.setText(history.toString);
	});

	private val jpConsole = new JPanel(false);
	jpConsole.add(bRDFQuery);
	jpConsole.add(bInsert);
	jpConsole.add(bRemove);
	jpConsole.add(bSubscribe);
	jpConsole.add(bUnsubscribe);

	/* 4_________________________________________________________ */
	// new
	private val tfSO = new JTextField("");
	private val tfPO = new JTextField("");
	private val tfOO = new JTextField("");
	private val tfSOType = new JTextField("");
	private val tfOOType = new JTextField("");

	tfSO.setColumns(10);
	tfPO.setColumns(10);
	tfOO.setColumns(10);
	tfSOType.setColumns(10);
	tfOOType.setColumns(10);

	private val jpTextFieldsNew = new JPanel(false);
	jpTextFieldsNew.add(new JLabel("Subject"));
	jpTextFieldsNew.add(tfSO);
	jpTextFieldsNew.add(new JLabel("Predicate"));
	jpTextFieldsNew.add(tfPO);
	jpTextFieldsNew.add(new JLabel("Object"));
	jpTextFieldsNew.add(tfOO);
	jpTextFieldsNew.add(new JLabel("Sub Type"));
	jpTextFieldsNew.add(tfSOType);
	jpTextFieldsNew.add(new JLabel("Obj Type"));
	jpTextFieldsNew.add(tfOOType);

	/* 5_________________________________________________________ */

	private val bUpdate = new JButton("Update");
	bUpdate.addActionListener(_=>{
		taMemo.setText("");

		val ret = kp.update((
				if (tfSN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfSN.getText,
				if (tfPN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfPN.getText,
				if (tfON.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfON.getText,
				tfSNType.getText, tfONType.getText), (
				if (tfSO.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfSO.getText,
				if (tfPO.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfPO.getText,
				if (tfOO.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfOO.getText,
				tfSOType.getText, tfOOType.getText));
		taMemo.append("Sent: " + kp.xmlTools.update((
				if (tfSN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfSN.getText,
				if (tfPN.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfPN.getText,
				if (tfON.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfON.getText,
				tfSNType.getText, tfONType.getText), (
				if (tfSO.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfSO.getText,
				if (tfPO.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfPO.getText,
				if (tfOO.getText == "*") "http://www.nokia.com/NRC/M3/sib#any" else tfOO.getText,
				tfSOType.getText, tfOOType.getText)) + "\n");

		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "\n");
		taMemo.append("\n*** SSAP message status:" + ret.status + "\n");
		history.append("rdf update sn = " + tfSN.getText + " p = " + tfPN.getText + " o = " + tfON.getText
				+ " ot = " + tfONType.getText + "so = " + tfSO.getText + " p = " + tfPO.getText + " o = "
				+ tfOO.getText + " ot = " + tfOOType.getText + "\n");

		taHistory.setText(history.toString);
	});
	private val bInsertProtection = new JButton("Insert Protection");
	bInsertProtection.addActionListener(_=>{
		taMemo.setText("");

		if (tfPN.getText == "" || tfSN.getText == "" || tfPN.getText == "*" || tfSN.getText == "*")
			taMemo.append("ERROR!!!\nSubject or predicate are empty, plese check!!!\n");
		else {
			val property = tfPN.getText;
			val ret = kp.insertProtection(tfSN.getText, property);
			val success = kp.xmlTools.isResponseConfirmed(ret);

			taMemo.append("INSERT PROTECTION:SUCCESS:" + (if (success) "YES" else "NO") + "\nKP-CORE MESSAGE:" + kp.errMess + "\n");
			taMemo.append("\n*** SSAP message status:" + ret.status + "\n");
		}
	});
	private val bRemoveProtection = new JButton("Remove Protection");
	bRemoveProtection.addActionListener(_=>{
		taMemo.setText("");

		if (tfPN.getText == "" || tfSN.getText == "" || tfPN.getText == "*" || tfSN.getText == "*")
			taMemo.append("ERROR!!!\nSubject or predicate are empty, plese check!!!\n");
		else {
			val property = tfPN.getText;
			val ret = kp.removeProtection(tfSN.getText, property);
			val success = kp.xmlTools.isResponseConfirmed(ret);
	
			taMemo.append("REMOVE PROTECTION:SUCCESS:" + (if (success) "YES" else "NO") + "\nKP-CORE MESSAGE:" + kp.errMess + "\n");
			taMemo.append("\n*** SSAP message status:" + ret.status + "\n");
		}
	});
	bInsertProtection.setForeground(Color.RED);
	bRemoveProtection.setForeground(Color.RED);

	private val jpUpdate = new JPanel(false);
	jpUpdate.add(bUpdate);
	jpUpdate.add(bInsertProtection);
	jpUpdate.add(bRemoveProtection);
	private val cbSUB = new JComboBox[ComboItemRenderable]();

	/* 6_________________________________________________________ */

	private val taMemo = new JTextArea(80, 25);
	taMemo.setFont(tfIP.getFont);

	/* 7___SPARQL________________________________________________ */

	private val bSPARQLquery = new JButton("SPARQL query");
	private val bSPARQLsubscription = new JButton("SPARQL subscription");
	private val bSPARQLUpdate = new JButton("SPARQL update");
	private val bRULE = new JButton("Persistent update");

	bSPARQLquery.addActionListener(_=>{
		// TEST
		taMemo.setText("");
		taMemo.append("\nSPARQL QUERY!");

		val ret = kp.querySparql(tfSQ.getText);
		taMemo.append("Sent: " + kp.xmlTools.querySparql(tfSQ.getText) + "\n");
		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "(" + kp.errID + ")\n");
		taMemo.append("SPARQLQuery confirmed:" + (if (kp.xmlTools.isResponseConfirmed(ret)) "YES" else "NO") + "\n");
		taMemo.append("\n*** SSAP message status:" + ret.status + "\n");

		if (ret != null) {
			val myresponse = ret.sparqlQueryResults;
			taMemo.append("\n-------------------------SPARQL QUERY--------------------------------\n");
			taMemo.append("It is " + myresponse.hasResults + " that has results\n");
			taMemo.append("Variable names are: " + myresponse.variableNames.mkString("{", ", ", "}") + "\n");
			taMemo.append("---------------------------------------------------------\n");
			taMemo.append("It is " + myresponse.hasLinks + " that has links\n");
			taMemo.append("Links are: " + myresponse.linkHrefs.mkString("{", ", ", "}") + "\n");
			taMemo.append("-------------------------GET SIZE--------------------------------\n");
			taMemo.append("Number of variables = " + myresponse.variableNames.size + "\n");
			taMemo.append("SIZE (number of results) = " + myresponse.size + "\n");
			taMemo.append("-------------------------GET Boolean--------------------------------\n");
			taMemo.append("It is " + myresponse.hasBooleans + " that has boolean value\n");
			if (myresponse.hasBooleans)
				taMemo.append("Boolean is " + myresponse.booleans(0) + "\n");
			taMemo.append("-------------------------GET RESULTS--------------------------------\n");
			taMemo.append("It is " + myresponse.hasResults + " that has results\n");
			taMemo.append("Results are:\n ");
			taMemo.append(myresponse.toString);
			history.append("sparql query s = " + tfSQ.getText + "\n");

		}
		taHistory.setText(history.toString);
	});
	bSPARQLsubscription.addActionListener(_=>{
		// TEST
		taMemo.setText("");
		taMemo.append("\nSPARQL Subscription!");

		val ret = kp.subscribeSparql(tfSQ.getText, this);
		val subID = ret.subscriptionID;
		taMemo.append("Sent: " + kp.xmlTools.subscribeSparql(tfSQ.getText) + "\n");

		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "(" + kp.errID + ")\n");
		taMemo.append("SPARQLQuery confirmed:" + (if (kp.xmlTools.isResponseConfirmed(ret)) "YES" else "NO") + "\n");
		taMemo.append("\n*** SSAP message status: " + ret.status + "\n");
		taMemo.append("\n*** subscriptionID:" + subID);
		val item = new ComboItemRenderable();
		item.name = subID;
		item.visualize = tfSQ.getText;
		cbSUB.addItem(item);
		if (ret != null) {
			val myresponse = ret.sparqlQueryResults;
			taMemo.append("\n-------------------------SPARQL QUERY--------------------------------\n");
			taMemo.append("It is " + myresponse.hasResults + " that has results\n");
			taMemo.append("Variable names are: " + myresponse.variableNames + "\n");
			taMemo.append("---------------------------------------------------------\n");
			taMemo.append("It is " + myresponse.hasLinks + " that has links\n");
			taMemo.append("Links are: " + myresponse.linkHrefs + "\n");
			taMemo.append("-------------------------GET SIZE--------------------------------\n");
			taMemo.append("Number of variables = " + myresponse.variableNames.size + "\n");
			taMemo.append("SIZE (number of results) = " + myresponse.size + "\n");
			taMemo.append("-------------------------GET RESULTS--------------------------------\n");
			taMemo.append("It is " + myresponse.hasResults + " that has results\n");

			taMemo.append("Results are: ");
			taMemo.append(myresponse.toString);
			history.append("sparql subscription s = " + tfSQ.getText + "\n");
			taHistory.setText(history.toString);
		}
	});
	bSPARQLUpdate.addActionListener(_=>{
		taMemo.setText("");
		taMemo.append("\nSPARQL Update!");

		val ret = kp.updateSparql(tfSQ.getText);
		history.append("Sparql update s = " + tfSQ.getText + "\n");

		taMemo.append("Sent: " + kp.xmlTools.updateSparql(tfSQ.getText) + "\n");
		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "(" + kp.errID + ")\n");

		taMemo.append("SPARQLUpdate confirmed:" + (if (kp.xmlTools.isResponseConfirmed(ret)) "YES" else "NO") + "\n");
		taMemo.append("\n*** SSAP message status:" + ret.status + "\n");

		taHistory.setText(history.toString);
	});
	bRULE.addActionListener(_=>{
		taMemo.setText("");
		taMemo.append("\nPersistent SPARQL Update!");
		val ret = kp.persistentUpdate(tfSQ.getText);
		taMemo.append("Sent: " + kp.xmlTools.persistentUpdate(tfSQ.getText) + "\n");

		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "(" + kp.errID + ")\n");
		taMemo.append("SPARQLUpdate Persistent confirmed:" + (if (kp.xmlTools.isResponseConfirmed(ret)) "YES" else "NO") + "\n");
		taMemo.append("\n*** SSAP message status:" + ret.status + "\n");

		val updateID = ret.updateID;
		val item = new ComboItemRenderable();
		item.name = updateID;
		item.visualize = tfSQ.getText;
		cbRULES.addItem(item);
		taMemo.append("Update ID:" + myLastSubscription + "\n");
		taMemo.append("\n*** SSAP message status:" + ret.status + "\n");
		history.append("persistent sparql update s = " + tfSQ.getText + "\n");

		taHistory.setText(history.toString);
	});

	private val bDelRULE = new JButton("Delte Pers Update");
	bDelRULE.setForeground(Color.BLUE);
	bDelRULE.addActionListener(_=>{
		taMemo.setText("");
		taMemo.append("Cancelling Rule ... waiting for the SIB answer...\n");
		val item = cbRULES.getSelectedItem.asInstanceOf[ComboItemRenderable];
		val ret = kp.cancelPersistentUpdate(item.name);
		cbRULES.removeItemAt(cbRULES.getSelectedIndex);
		taMemo.append("Sent: " + kp.xmlTools.cancelPersistentUpdate(item.name) + "\n");

		taMemo.append("SIB MESSAGE:\n" + ret + "\nKP-CORE MESSAGE:" + kp.errMess + "\n");
		// taMemo.append("Cancel Persistent Update
		// confirmed:"+(xmlTools.isUnSubscriptionConfirmed(ret)?"YES":"NO")+"\n");
		taMemo.append("...ok:" + ret + "\n");
		taMemo.append("\n*** SSAP message status:" + ret.status + "\n");
		history.append("cancel persistent update: " + item + "\n");

		taHistory.setText(history.toString);
	});

	private val labelz = new JLabel("SPARQL query");
	// labelz.setForeground(Color.RED);
	private val tfSQ = new JTextField("");
	tfSQ.setColumns(30);
	tfSQ.addActionListener(bSPARQLquery.getActionListeners()(0));

	bSPARQLUpdate.setForeground(Color.BLUE);
	bRULE.setForeground(Color.BLUE);

	private val jpSparql = new JPanel(false);
	jpSparql.add(labelz);
	jpSparql.add(tfSQ);
	jpSparql.add(bSPARQLquery);
	jpSparql.add(bSPARQLsubscription);
	jpSparql.add(bSPARQLUpdate);
	jpSparql.add(bRULE);
	jpSparql.add(bDelRULE);

	private val cbRULES = new JComboBox[ComboItemRenderable]();

	/* 8___Subscriptions___and Rules_____ */
	private val jpSubscriptions = new JPanel(false);
	private var labelSub = new JLabel("Active subscriptions");
	jpSubscriptions.add(labelSub);
	jpSubscriptions.add(cbSUB);
	labelSub = new JLabel("Active subscription");
	/* _________________________________________________________ */

	labelSub = new JLabel("Active persistent updates");
	labelSub.setForeground(Color.BLUE);
	jpSubscriptions.add(labelSub);
	jpSubscriptions.add(cbRULES);
	// label_sub = new JLabel("Active persistent updates");
	// labelx.setForeground(Color.BLUE);
	/* _________________________________________________________ */

	private val jpMain = new JPanel(true);
	jpMain.setLayout(new GridLayout(1, 1));
	jpMain.add(jpConnection, 0);

	//private val jpMemo = new JPanel(false);
	//jpMemo.setLayout(new FlowLayout());
	// ADD HERE A SCROLL BAR PANE
	// jpMemo.add(taMemo);
	private val jpMemo = new JScrollPane(taMemo);
	//sbrText.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
	//jpMemo.add(sbrText);

	taMemo.append("OK!");

	setLayout(new BorderLayout());
	add(jpMain, BorderLayout.SOUTH);
	// add( jpMemo, BorderLayout.NORTH );

	private val taHistory = new JTextArea();
	taHistory.setFont(tfIP.getFont);

	println("GUI DONE!");

	// validateTree();

	/**Just a friendly method to print results on the console!*/
	def printResultsOnTaMemo(resultsList:Seq[(String,String,String,String,String)]*) {
		for (i <- 0 until resultsList.size) {
			taMemo.append("\n----- Result " + i + ":");
			for (j <- 0 until resultsList(i).size)
				taMemo.append("\n--- row " + j + ":" + resultsList(i)(j))
		}
	}

	// scroolbars:
	// http://www.roseindia.net/java/java-tips/GUI/components/40textarea/25ex-textarea.shtml

	/* ___________________________________________________________________ */
	private def memo(n:String) = taMemo.append(n);

	/* ____________________________________________________________________ */

	override def kpicRDFEventHandler(newTriples:Seq[(String,String,String,String,String)], oldTriples:Seq[(String,String,String,String,String)], indSequence:String, subID:String) {
		var temp = "\n Notif. " + indSequence + " id = " + subID + "\n";
		temp += newTriples.map(t=>s"New triple subject = ${t._1} + predicate = ${t._2} + object = ${t._3}\n").mkString;
		temp += oldTriples.map(t=>s"Obsolete triple subject = ${t._1} + predicate = ${t._2} + object = ${t._3}\n").mkString;
		println(temp);
		taMemo.append(temp);
		taMemo.repaint();
	}

	override def kpicSparqlEventHandler(newResults:SSAPSparqlResponse, oldResults:SSAPSparqlResponse, indSequence:String, subID:String) {
		taMemo.append("\n Notif. " + indSequence + " id = " + subID + "\n");
		if (newResults != null) {
			println("new: \n " + newResults);
			taMemo.append("new: \n " + newResults);
			taMemo.repaint();
		}
		if (oldResults != null) {
			println("obsolete: \n " + oldResults);
			taMemo.append("obsolete: \n " + oldResults);
			taMemo.repaint();
		}
	}

	override def kpicUnsubscribeEventHandler(subID:String) {
		println("Unsubscribed " + subID);
		taMemo.append("Unsubscribed " + subID);
	}

	override def kpicExceptionEventHandler(socketException:Throwable) {
		println("Exception in subscription handler " + socketException);
		taMemo.append("Exception in subscription handler " + socketException);
		taMemo.repaint();
	}
	
	//override def subscriptionID = myLastSubscription;
	private class ComboItemRenderable {
		var name = "";
		var visualize = "";

		override def toString() = visualize;
	}
}