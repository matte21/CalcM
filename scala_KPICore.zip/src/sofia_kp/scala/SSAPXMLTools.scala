package sofia_kp.scala

import java.io._;

import scala.collection.JavaConverters._

import org.jdom2._;
import org.jdom2.input._;

object SSAPXMLTools {
	val ANYURI = "http://www.nokia.com/NRC/M3/sib#any";

	/* * * * * * * * * * * * * * * * * * * *\ List of every WQL query types \* * * * * * * * * * * * * * * * * * * */
	val WQL_VALUES = "WQL-VALUES";
	val WQL_RELATED = "WQL-RELATED";
	val WQL_NODETYPES = "WQL-NODETYPES";
	val WQL_ISTYPE = "WQL-ISTYPE";
	val WQL_ISSUBTYPE = "WQL-ISSUBTYPE";
}
/**
 * SSAP_XMLTools is the class to handle the SIB messages. 
 * <p>
 * It store internally the last XML message received 
 * from the SIB for XML parsing purpose.
 * It maintain a transaction counter 
 * <p>
 * @author      Daniele Manzaroli - VTT-Oulu, Technical Research Centre of Finland. ARCES, University of Bologna, Italy
 * @version     %I%, %G%
 * @param nodeID
 *            the KPI node ID
 * @param SMART_SPACE_NAME
 *            the smart space name
 * @param ANYURI
 *            the URI you are going to use in the SIB
*/
class SSAPXMLTools(val nodeID:String, smartSpaceName:String, anyURI:String) {
	
	//nodeID: SSAP specification protocol element
	/**Object constructor. To be able to use just the XML parser methods*/
	def this() = this("00000000-0000-0000-0000-DEAD0000BEEF", null, SSAPXMLTools.ANYURI)

	private[sofia_kp] var builder = new SAXBuilder;
	private[sofia_kp] var messageDoc = null:Document;

	private var transactionID = 0;
	private var subscriptionID = 0;

	/**
	 * Collect all the values of each xml tag id specified into an hashtable
	 * looking for into a string representation of an xml document. All id
	 * passed are not mandatory to be found in this version.
	 * 
	 * @param xml
	 *            the xml documento to parse
	 * @param id
	 *            array of all xml tag to find into the document
	 * @return an hashtable containing all the couple id-value
	 */
	def SibXMLMessageParser(xml:String, id:Array[String]) = {
		if (xml == null)
			throw new IllegalArgumentException("XML message is null");
		
		if (id == null)
			throw new IllegalArgumentException("id is null");
		
		val doc = builder.build(new ByteArrayInputStream(xml.getBytes));
		if (doc == null)
			throw new IllegalArgumentException("doc is null");

		val root = doc.getRootElement;
		
		id.map(i=>i->root.getChild(i, root.getNamespace).getText).toMap
	}

	/**
	 * Check if every element of the id array have into the last SIB XML message
	 * a corresponding value from the ref array.
	 * 
	 * @param id
	 *            List of SIB XML message tag to check
	 * @param ref
	 *            references values for each tag id
	 * @return true if all the values into the last SIB XML message match with
	 *         the values in the ref array, false otherwise. Each id is
	 *         mandatory, so if the size of hashtable is less then id array, it
	 *         will return false.
	 */
	def autoCheckSibMessage(xml:String, id:Array[String], ref:Array[String]) = {
		val map = SibXMLMessageParser(xml, id);

		if (map == null)
			false;

		else if (map.size < id.length)
			false;

		else
			id.zip(ref).forall(r=>map(r._1)==r._2);
	}

	/**
	 * By specifying an xml attribute and value, the xml content will be return
	 * as Element object
	 * 
	 * @param xml
	 *            the xml SIB message
	 * @param attribute
	 *            the attribute you are looking for
	 * @param value
	 *            the value of the attribute
	 * @return the Element object that contain the attribute xml content
	 */

	def getParameterElement(xml:String, attribute:String, value:String) = {
		if (xml == null)
			throw new IllegalArgumentException("XML message is null");

		val doc = builder.build(new ByteArrayInputStream(xml.getBytes));
		if (doc == null)
			throw new IllegalArgumentException("doc is null");

		val root = doc.getRootElement;

		root.getChildren("parameter", root.getNamespace).asScala.find(_.getAttributeValue(attribute)==value).getOrElse(throw new IllegalArgumentException(s"parameter($attribute=$value) not found!"))
	}

	/**
	 * Looking for the join confirmation in the last XML message received from
	 * the SIB
	 * 
	 * @return true if the confirmation is found, false otherwise
	 */
	def isJoinConfirmed(xml:String) = autoCheckSibMessage(xml, Array("transaction_type", "message_type"), Array("JOIN", "CONFIRM")) && getParameterElement(xml, "name", "status").getValue == "m3:Success"
	
	/**
	 * Looking for the leave confirmation in the last XML message received from
	 * the SIB
	 * 
	 * @return true if the confirmation is found, false otherwise
	 */
	def isLeaveConfirmed(xml:String) = autoCheckSibMessage(xml, Array("transaction_type", "message_type"), Array("LEAVE", "CONFIRM")) && getParameterElement(xml, "name", "status").getValue.equals("m3:Success");

	/**
	 * Looking for the Query confirmation in the last XML message received from
	 * the SIB
	 * 
	 * @return true if the confirmation is found, false otherwise
	 */
	def isQueryConfirmed(xml:String) = autoCheckSibMessage(xml, Array("transaction_type", "message_type"), Array("QUERY", "CONFIRM")) && getParameterElement(xml, "name", "status").getValue.equals("m3:Success");

	/**
	 * Looking for the Update confirmation in the last XML message received from
	 * the SIB
	 * 
	 * @return true if the confirmation is found, false otherwise
	 */
	def isUpdateConfirmed(xml:String) = autoCheckSibMessage(xml, Array("transaction_type", "message_type"), Array("UPDATE", "CONFIRM")) && getParameterElement(xml, "name", "status").getValue.equals("m3:Success");

	/**
	 * Get all the triple as list of strings from a RDF query answer message
	 * 
	 * @param xml
	 *            the SIB xml message
	 * @return a list of all triples available in the xml SIB message passed. It
	 *         is a structure to store every triple. Each element of the list
	 *         contains another list formed by four string elements : -the
	 *         subject -the predicate -the object -the subject type -the object
	 *         type
	 * 
	 */
	def getQueryTriple(xml:String):Seq[(String,String,String,String,String)] = {
		if (xml == null)
			throw new IllegalArgumentException("XML message is null");

		val doc = builder.build(new ByteArrayInputStream(xml.getBytes));
		if (doc == null)
			throw new IllegalArgumentException("doc is null");

		val root = doc.getRootElement;
		var ns = root.getNamespace;

		val triples = root.getChildren("parameter", ns).asScala.find(_.getAttributeValue("name")=="results").getOrElse(throw new IllegalArgumentException("parameter(results) not found!")).getChild("triple_list", ns);
		if (triples == null)
			throw new Exception("triples not found");
		
		triples.getChildren("triple", ns).asScala.map(t=>(t.getChild("subject", ns).getText, t.getChild("predicate", ns).getText, t.getChild("object", ns).getText, "URI", t.getChild("object", ns).getAttributeValue("type")));
	}

	/**
	 * Get the first occurence of the Object in a triple by specify the
	 * Predicate value
	 * 
	 * @param tripleList
	 *            a list of triple string representation. It is a structure to
	 *            store every triple. Each element of the list contains
	 *            another list formed by five string elements : -the subject
	 *            -the predicate -the object -the subject type -the object type
	 * 
	 * @param predicate
	 *            xml SIB message triple predicate
	 * @return the string representation of the object
	 */
	def getTripleObjectByPredicate(tripleList:Seq[(String,String,String,String,String)], predicate:String) = tripleList.find(t=>t!=null && t._2==predicate).map(_._3).getOrElse(null);

	/**
	 * Get the index of the first occurrence of the triple in a triple list by
	 * specify the Predicate value
	 * 
	 * @param tripleList
	 *            a list of triple string representation. It is a structure to
	 *            store every triple. Each element of the list contains
	 *            another list formed by five string elements : -the subject
	 *            -the predicate -the object -the subject type -the object type
	 * 
	 * @param predicate
	 *            xml SIB message triple predicate
	 * @return the index of the first predicate occurrence in the triple list
	 */
	def getTripleIndexByPredicate(tripleList:Seq[(String,String,String,String,String)], predicate:String) = tripleList.indexWhere(t=>t!=null && t._2==predicate);

	/**
	 * Get the new triple value from an event SIB message
	 * 
	 * @param xml
	 *            the SIB xml message
	 * @return a list of the string representation of every triple available
	 *         into the event SIB xml message. It is a structure to store every
	 *         triple. Each element of the list contains another list formed
	 *         by five string elements : -the subject -the predicate -the object
	 *         -the object type
	 *
	 */
	def getNewResultEventTriple(xml:String) = getEventTriple(xml, "new_results");

	/**
	 * Get the obsolete triple value from an event SIB message
	 * 
	 * @param xml
	 *            the SIB xml message
	 * @return a list of the string representation of every triple available
	 *         into the event SIB xml message. It is a structure to store every
	 *         triple. Each element of the list contains another list formed
	 *         by five string elements : -the subject -the predicate -the object
	 *         -the object type
	 *
	 */
	def getObsoleteResultEventTriple(xml:String) = getEventTriple(xml, "obsolete_results");

	/**
	 * Get the triple value from an event SIB message by specifying the
	 * parameter attribute value
	 * 
	 * @param xml
	 *            the SIB xml message
	 * @param ParamAttValue
	 *            parameter attribute value like "obsolete_results" or
	 *            "new_results"
	 * @return a list of the string representation of every triple available
	 *         into the event SIB xml message. It is a structure to store every
	 *         triple. Each element of the list contains another list formed
	 *         by five string elements : -the subject -the predicate -the object
	 *         -the object type
	 *
	 */
	private def getEventTriple(xml:String, paramAttValue:String):Seq[(String,String,String,String,String)] = {
		if (xml == null)
			throw new IllegalArgumentException("XML message is null");

		val parameters = getParameterElement(xml, "name", paramAttValue);
		if (parameters == null)
			throw new IllegalArgumentException("parameters not found:" + paramAttValue);

		val triples = parameters.getChild("triple_list");
		if (triples == null)
			throw new IllegalArgumentException("triple_list not found");

		triples.getChildren("triple").asScala.map(t=>(t.getChild("subject").getText, t.getChild("predicate").getText, t.getChild("object").getText, "URI", t.getChild("object").getAttributeValue("type")));
	}

	/**
	 * Looking for the Subscription confirmation in the last XML message
	 * received from the SIB
	 * 
	 * @param xml
	 *            the SIB xml message
	 * 
	 * @return true if the confirmation is found, false otherwise
	 */
	def isSubscriptionConfirmed(xml:String) = autoCheckSibMessage(xml, Array("transaction_type", "message_type"), Array("SUBSCRIBE", "CONFIRM")) && getParameterElement(xml, "name", "status").getValue =="m3:Success";

	/**
	 * Looking for the UnSubscription confirmation in the last XML message
	 * received from the SIB
	 *
	 * @param xml
	 *            the SIB xml message
	 * @return true if the confirmation is found, false otherwise
	 */
	def isUnsubscriptionConfirmed(xml:String) = autoCheckSibMessage(xml, Array("transaction_type", "message_type"), Array("UNSUBSCRIBE", "CONFIRM")) && getParameterElement(xml, "name", "status").getValue =="m3:Success";

	/**
	 * Looking for the Insert confirmation in the last XML message received from
	 * the SIB
	 * 
	 * @param xml
	 *            the SIB xml message
	 * @return true if the confirmation is found, false otherwise
	 */
	def isInsertConfirmed(xml:String) = autoCheckSibMessage(xml, Array("transaction_type", "message_type"), Array("INSERT", "CONFIRM")) && getParameterElement(xml, "name", "status").getValue =="m3:Success";

	/**
	 * Looking for the Remove confirmation in the last XML message received from
	 * the SIB
	 * 
	 * @param xml
	 *            the SIB xml message
	 * @return true if the confirmation is found, false otherwise
	 */
	def isRemoveConfirmed(xml:String) = autoCheckSibMessage(xml, Array("transaction_type", "message_type"), Array("REMOVE", "CONFIRM")) && getParameterElement(xml, "name", "status").getValue =="m3:Success";

	/**
	 * The event subscription confirmation message bring with him an
	 * eventSubscripptionID This method return the event subscriptionID
	 * 
	 * @param xml
	 *            the SIB xml message
	 * @return the event subscription ID if available
	 */
	def getSubscriptionID(xml:String) = getParameterElement(xml, "name", "subscription_id").getValue;
	// <parameter name = "subscription_id">2</parameter>
	
	/**
	 * The persistent update confirmation message bring with him an updatedID
	 * This method return the updatedID
	 * 
	 * @param xml
	 *            the SIB xml message
	 * @return the event subscription ID if available
	 */
	def getUpdateID(xml:String) = getParameterElement(xml, "name", "update_id").getValue;
	// <parameter name = "update_id">2</parameter>
	
	/**
	 * Method to print on the standard output the triple content
	 * 
	 * @param xml
	 *            the SIB xml message
	 */
	def printTriple(xml:String) {
		val triples = getQueryTriple(xml);
		if (triples != null) {
			println("Triple List:\n");
			triples.foreach(t=>println(s"S:[${t._1}] P:[${t._2}] O:[${t._3}] Stype:[${t._4}] Otype:[${t._5}]"));
		} else
			System.err.println("NO TRIPLE FOUND!!!");
	}

	/*
	 * 
	 * M3 XML messages makers
	 * 
	 **/

	/**
	 * Make the JOIN SSAP message
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def join() = {
		transactionID+=1;
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>JOIN</transaction_type><transaction_id>" + transactionID +
				"</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName + "</space_id></SSAP_message>";
	}

	/**
	 * Make the LEAVE SSAP message
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def leave() = {
		transactionID+=1;
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>LEAVE</transaction_type><transaction_id>" + transactionID +
				"</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName + "</space_id></SSAP_message>";
	}

	/**
	 * Make the RDF Query SSAP message
	 * 
	 * @param triples
	 *            is a structure to store every triple. Each element of the
	 *            list contains another list formed by five string elements
	 *            : -the subject -the predicate -the object -the subject type
	 *            -the object type
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def queryRDF(triples:Seq[(String,String,String,String,String)]) = {
		transactionID+=1;
		"<SSAP_message><transaction_type>QUERY</transaction_type><message_type>REQUEST</message_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
				"</space_id><parameter name = \"type\">RDF-M3</parameter><parameter name = \"query\">" +
				getTripleXmlListFromTriples(triples) + "</parameter></SSAP_message>";
	}
	def queryRDF(triple:(String,String,String,String,String), triples:(String,String,String,String,String)*):String = queryRDF(triple +: triples);
	
	/**
	 * Transform the list triple representation in String representation
	 * 
	 * @param tripleList
	 *            is a structure to store every SSAP triple. Each element of the
	 *            list contains another list formed by five string elements
	 *            : -the subject -the predicate -the object -the subject type
	 *            -the object type
	 * 
	 * @return a string representation of the XML that represent the triple list
	 *         for the SSAP message
	 */
	private def getTripleXmlListFromTriples(triples:Seq[(String,String,String,String,String)]) = triples.map(t=>
			"<triple><subject type=\"" + (if (t._1 == null) "URI" else t._4) + "\">" + (if (t._1 == null) anyURI else t._1) +
			"</subject><predicate>" + (if (t._2 == null) anyURI else t._2) + "</predicate><object type=\"" + (if (t._3 == null) "URI" else t._5) +
			"\"><![CDATA[" + (if (t._3 == null) anyURI else correctEntityReferences(t._3.replaceAll("[^\\x20-\\x7e]", "?"))) + "]]></object></triple>")
		.mkString("<triple_list>","","</triple_list>")

	/**
	 * Make the INSERT SSAP message
	 * 
	 * @param triples
	 *            is a structure to store every triple. Each element of the
	 *            list contains another list formed by five string elements
	 *            : -the subject -the predicate -the object -the subject type
	 *            -the object type
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def insert(triples:Seq[(String,String,String,String,String)]) = {
		transactionID+=1;
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>INSERT</transaction_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
				"</space_id><parameter name=\"confirm\">TRUE</parameter><parameter name=\"insert_graph\"  encoding=\"RDF-M3\">" +
				getTripleXmlListFromTriples(triples) + "</parameter></SSAP_message>";
	}
	def insert(triple:(String,String,String,String,String), triples:(String,String,String,String,String)*):String = insert(triple +: triples);

	/**
	 * Make the REMOVE SSAP message
	 * 
	 * @param triples
	 *            is a structure to store every triple. Each element of the
	 *            list contains another list formed by five string elements
	 *            : -the subject -the predicate -the object -the subject type
	 *            -the object type
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def remove(triples:Seq[(String,String,String,String,String)]) = {
		transactionID+=1;
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>REMOVE</transaction_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
				"</space_id><parameter name=\"confirm\">TRUE</parameter><parameter name=\"remove_graph\"  encoding=\"RDF-M3\">" +
				getTripleXmlListFromTriples(triples) + "</parameter></SSAP_message>";
	}
	def remove(triple:(String,String,String,String,String), triples:(String,String,String,String,String)*):String = remove(triple +: triples);

	/**
	 * Make the UPDATE SSAP message
	 *
	 *  New value to insert:
	 * @param newTripleList
	 *            contains: -the string representation of the new
	 *            subject -the string representation of the new predicate -the
	 *            string representation of the new object -the string
	 *            representation of the new subject type. Allowed values are:
	 *            uri, literal -the string representation of the new object
	 *            type. Allowed values are: uri, literal
	 * 
	 * Old value to replace:
	 * @param oldTripleList
	 *            contains: -the string representation of the old
	 *            subject -the string representation of the old predicate -the
	 *            string representation of the object -the string representation
	 *            of the old subject type. Allowed values are: uri, literal -the
	 *            string representation of the old object type. Allowed values
	 *            are: uri, literal
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def update(newTriple:(String,String,String,String,String), oldTriple:(String,String,String,String,String)):String = update(List(newTriple),List(oldTriple));

	/**
	 * Make the UPDATE SSAP message
	 * 
	 * New value to insert:
	 * 
	 * @param newTripleList
	 *            the structure to store every new triple to insert. Each
	 *            element contains: -the string representation of the new
	 *            subject -the string representation of the new predicate -the
	 *            string representation of the new object -the string
	 *            representation of the new subject type. Allowed values are:
	 *            uri, literal -the string representation of the new object
	 *            type. Allowed values are: uri, literal
	 * 
	 *            Old value to replace:
	 * @param oldTripleList
	 *            the structure to store every old triple to replace. Each
	 *            element contains: -the string representation of the old
	 *            subject -the string representation of the old predicate -the
	 *            string representation of the object -the string representation
	 *            of the old subject type. Allowed values are: uri, literal -the
	 *            string representation of the old object type. Allowed values
	 *            are: uri, literal
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def update(newTripleList:Seq[(String,String,String,String,String)], oldTripleList:Seq[(String,String,String,String,String)]) = {
		transactionID+=1;
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>UPDATE</transaction_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
				"</space_id><parameter name = \"insert_graph\" encoding = \"RDF-M3\">" + getTripleXmlListFromTriples(newTripleList) +				// insert (NEW)
				"</parameter><parameter name = \"remove_graph\" encoding = \"RDF-M3\">" + getTripleXmlListFromTriples(oldTripleList) +	// remove (OLD)
				"</parameter><parameter name = \"confirm\">TRUE</parameter></SSAP_message>";
	}

	/**
	 * Make the SUBSCRIPTION SSAP message
	 * 
	 * @param triples
	 *            the triples patterns to subscribe
	 * 
	 * @return a string representation of the XML message to send to the SIB
	 */
	def subscribeRDF(triples:Seq[(String,String,String,String,String)]) = {
		transactionID+=1;
		subscriptionID = transactionID;

		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>SUBSCRIBE</transaction_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
				"</space_id><parameter name=\"type\">RDF-M3</parameter><parameter name=\"query\">" + getTripleXmlListFromTriples(triples) +
				"</parameter></SSAP_message>";

	}
	def subscribeRDF(triple:(String,String,String,String,String), triples:(String,String,String,String,String)*):String = subscribeRDF(triple +: triples);

	def subscribeSparql(query:String) = {
		transactionID+=1;	// FIXME MAYBE
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>SUBSCRIBE</transaction_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
				"</space_id><parameter name = \"type\">sparql</parameter><parameter name = \"query\">" +
				//"<![CDATA[" +
				correctEntityReferences(query) +
				//"]]>" +
				"</parameter></SSAP_message>";
	}

	/**
	 * Make the UNSUBSCRIBE SSAP message
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def unsubscribe() = {
		transactionID+=1;
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>UNSUBSCRIBE</transaction_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
				"</space_id><parameter name = \"subscription_id\">" + subscriptionID + "</parameter></SSAP_message>";
	}

	def cancelPersistentUpdate(updateID:String) = {
		transactionID+=1;
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>CANCEL_PERSISTENT_UPDATE</transaction_type><transaction_id>" +
		transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName + 
		"</space_id><parameter name = \"update_id\">" + updateID + "</parameter></SSAP_message>";
	}

	/**
	 * Make the UNSUBSCRIBE SSAP message for a specific subscription ID
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def unsubscribe(subscriptionID:String) = {
		transactionID+=1;	// FIXME MAYBE
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>UNSUBSCRIBE</transaction_type><transaction_id>" +
		transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
		"</space_id><parameter name = \"subscription_id\">" + subscriptionID + "</parameter></SSAP_message>";
	}

	/*
	 * * * * * * * * * * * * * * * * * * *\ WQL querys \* * * * * * * * * * * * * * * * * * *
	 */

	/**
	 * Make the WQL-QUERY SSAP message
	 * 
	 * @param startNodeURI
	 *            the string representation of the node URI
	 * @param type
	 *            the string representation of the node URI type. Can be
	 *            "literal" or "URI"
	 * @param path
	 *            the string representation of the WQL graph path
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def queryWQLValues(startNodeURI:String, nodeType:String, path:String) = queryWQLSurround(SSAPXMLTools.WQL_VALUES, newXmlNodeTag("start", nodeType, startNodeURI), newXmlPathExpressionTag(path))

	/**
	 * Make the WQL-QUERY SSAP message
	 * 
	 * @param startNodeURI
	 *            the string representation of the start node URI
	 * @param startType
	 *            the string representation of the node URI type. Can be
	 *            "literal" or "URI"
	 * @param endNodeURI
	 *            the string representation of the end node URI
	 * @param endType
	 *            the string representation of the node URI type. Can be
	 *            "literal" or "URI"
	 * @param path
	 *            the string representation of the WQL graph path
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def queryWQLRelated(startNodeURI:String, startType:String, endNodeURI:String, endType:String, path:String) = queryWQLSurround(SSAPXMLTools.WQL_RELATED, newXmlNodeTag("start", startType, startNodeURI), newXmlNodeTag("end", endType, endNodeURI), newXmlPathExpressionTag(path));

	/**
	 * Make the WQL-QUERY SSAP message
	 *
	 * 
	 * @param nodeURI
	 *            the string representation of the node URI
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def queryWQLNodeTypes(nodeURI:String) = queryWQLSurround(SSAPXMLTools.WQL_NODETYPES, newXmlNodeTag(nodeURI));

	/**
	 * Make the WQL-QUERY SSAP message
	 *
	 * 
	 * @param nodeURI
	 *            the string representation of the node URI
	 * @param nodeType
	 *            the string representation of the node URI type. Can be
	 *            "literal" or "URI"
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def queryWQLIsTypes(nodeURI:String, nodeType:String) = queryWQLSurround(SSAPXMLTools.WQL_ISTYPE, newXmlNodeTag("", "", nodeURI), newXmlNodeTag("type", "", nodeType));

	/**
	 * Make the WQL-QUERY SSAP message
	 *
	 * 
	 * @param subClassNodeURI
	 *            the string representation of a sub-class node URI
	 * @param superClassNodeURI
	 *            the string representation of a super-class node URI
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def queryWQLIsSubtype(subClassNodeURI:String, superClassNodeURI:String) = queryWQLSurround(SSAPXMLTools.WQL_ISSUBTYPE, newXmlNodeTag("subtype", "", subClassNodeURI), newXmlNodeTag("supertype", "", superClassNodeURI));

	/**
	 * Method to build an XML node tag for WQL query purpose
	 * 
	 * @param name
	 *            the node name
	 * @param type
	 *            the node type. Can be "literal" or "URI"
	 * @param content
	 *            the node content
	 * 
	 * @return a string representation of WQL query node tag
	 */
	private def newXmlNodeTag(name:String, nodeType:String, content:String) = "<node " + (if (name=="") "" else s"""name="$name" """) + (if (nodeType=="") "" else s"""type="$nodeType" """) + ">" + content + "</node>";

	/**
	 * Method to build an XML node tag for WQL query purpose
	 * 
	 * @param content
	 *            the node content
	 * 
	 * @return a string representation of WQL query node tag
	 */
	private def newXmlNodeTag(content:String) = "<node>" + content + "</node>";

	/**
	 * Method to build an XML path_expression tag for WQL query purpose
	 * 
	 * @param path
	 *            the path
	 * 
	 * @return a string representation of WQL query path_expression tag
	 */
	private def newXmlPathExpressionTag(path:String) = "<path_expression>" + path + "</path_expression>";

	/**
	 * Method to complete the XML message for the wilbur query. This method
	 * surround the string representation of the all nodes needed for the query
	 * with the minimum basic xml code to complete the message.
	 * 
	 * @param wqlQueryNodes
	 *            the string representation of all node tags for the wilbur
	 *            query as show below:
	 *            <node>.....</node><node>.....</node><node>.....</node>
	 * 
	 * @return the string representation of the final XML message for the wilbur
	 *         query
	 */
	private def queryWQLSurround(queryWQLType:String, wqlQueryNodes:String*) = {
		transactionID+=1;
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>QUERY</transaction_type><transaction_id>" + 
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName + 
				"</space_id><parameter name = \"type\">" + queryWQLType + "</parameter><parameter name = \"query\"><wql_query>" +
				wqlQueryNodes.mkString("") + "</wql_query></parameter></SSAP_message>";
	}

	/*
	 * * * * * * * * * * * * * * * * * * *\ WQL subscription \* * * * * * * * * * * * * * * * * * *
	 */

	/**
	 * Make the WQL-QUERY SUBSCRIPTION SSAP message
	 *
	 * 
	 * @param startNodeURI
	 *            the string representation of the node URI
	 * @param type
	 *            the string representation of the node URI type. Can be
	 *            "literal" or "URI"
	 * @param path
	 *            the string representation of the WQL graph path
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def subscribeWQLValues(startNodeURI:String, nodeType:String, path:String) = subscribeWQLSurround(SSAPXMLTools.WQL_VALUES, newXmlNodeTag("start", nodeType, startNodeURI), newXmlPathExpressionTag(path));

	/**
	 * Make the WQL-QUERY SUBSCRIPTION SSAP message
	 *
	 * 
	 * @param startNodeURI
	 *            the string representation of the start node URI
	 * @param startType
	 *            the string representation of the node URI type. Can be
	 *            "literal" or "URI"
	 * @param endNodeURI
	 *            the string representation of the end node URI
	 * @param endType
	 *            the string representation of the node URI type. Can be
	 *            "literal" or "URI"
	 * @param path
	 *            the string representation of the WQL graph path
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def subscribeWQLRelated(startNodeURI:String, startType:String, endNodeURI:String, endType:String, path:String) = subscribeWQLSurround(SSAPXMLTools.WQL_RELATED, newXmlNodeTag("start", startType, startNodeURI), newXmlNodeTag("end", endType, endNodeURI), newXmlPathExpressionTag(path));

	/**
	 * Make the WQL-QUERY SUBSCRIPTION SSAP message
	 *
	 * 
	 * @param nodeURI
	 *            the string representation of the node URI
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def subscribeWQLNodeTypes(nodeURI:String) = subscribeWQLSurround(SSAPXMLTools.WQL_NODETYPES, newXmlNodeTag(nodeURI));

	/**
	 * Make the WQL-QUERY SUBSCRIPTION SSAP message
	 *
	 * 
	 * @param nodeURI
	 *            the string representation of the node URI
	 * @param nodeType
	 *            the string representation of the node URI type. Can be
	 *            "literal" or "URI"
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def subscribeWQLIsTypes(nodeURI:String, nodeType:String) = subscribeWQLSurround(SSAPXMLTools.WQL_ISTYPE, newXmlNodeTag("start", "", nodeURI), newXmlNodeTag("type", "", nodeType));

	/**
	 * Make the WQL-QUERY SUBSCRIPTION SSAP message
	 *
	 * 
	 * @param subClassNodeURI
	 *            the string representation of a sub-class node URI
	 * @param superClassNodeURI
	 *            the string representation of a super-class node URI
	 * 
	 * @return a string representation of the XML answer message from the SIB
	 */
	def subscribeWQLIsSubtype(subClassNodeURI:String, superClassNodeURI:String) = subscribeWQLSurround(SSAPXMLTools.WQL_ISSUBTYPE, newXmlNodeTag("subtype", "", subClassNodeURI), newXmlNodeTag("supertype", "", superClassNodeURI));

	def subscribeWQLSurround(wqlValues:String, wqlQueryNodes:String*) = {
		transactionID+=1;
		subscriptionID = transactionID;

		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>SUBSCRIBE</transaction_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName + 
				"</space_id><parameter name = \"type\">" + wqlValues + "</parameter><parameter name = \"query\"><wql_query>" +
				wqlQueryNodes.mkString("") + "</wql_query></parameter></SSAP_message>";
	}

	/**
	 * Returns true if the received notification is relative to an RDF-M3
	 * subscription
	 * 
	 * @param xml
	 *            String received from SIB as a notification
	 * @return
	 */
	def isRDFNotification(xml:String) = {
		//var isRDF = false;
		if (xml == null)
			throw new IllegalArgumentException("XML message is null");

		val doc = builder.build(new ByteArrayInputStream(xml.getBytes));
		if (doc == null)
			throw new IllegalArgumentException("doc is null");

		val root = doc.getRootElement;
		val parameters = root.getChildren("parameter", root.getNamespace).asScala;
		val pNew = parameters.find(_.getAttributeValue("name").equalsIgnoreCase("new_results")).getOrElse(new Element(""));
		val pOld = parameters.find(_.getAttributeValue("name").equalsIgnoreCase("obsolete_results")).getOrElse(new Element(""));

		if (pNew.getChildren.size > 0)
			pNew.getChildren.get(0).getName.equalsIgnoreCase("triple_list");
		else if (pOld.getChildren.size > 0)
			pOld.getChildren.get(0).getName.equalsIgnoreCase("triple_list");
		else true;
	}

	/**
	 * Returns the subject of a triple with a given triple represented ina
	 * List<String>
	 * 
	 * @param t
	 *            A List<String> representing a triple
	 * @return the subject of the triple
	 */
	def getTripleSubject(t:(String,String,String,String,String)) = t._1;

	/**
	 * Returns the predicate of a triple with a given triple represented ina
	 * List<String>
	 * 
	 * @param t
	 *            A List<String> representing a triple
	 * @return the predicate of the triple
	 */
	def getTriplePredicate(t:(String,String,String,String,String)) = t._2;

	/**
	 * Returns the object of a triple with a given triple represented ina
	 * List<String>
	 * 
	 * @param t
	 *            A List<String> representing a triple
	 * @return the object of the triple
	 */
	def getTripleObject(t:(String,String,String,String,String)) = t._3;

	/**
	 * Returns the object type of a triple with a given triple represented ina
	 * List<String>
	 * 
	 * @param t
	 *            A List<String> representing a triple
	 * @return the subject type of the triple
	 */
	@deprecated
	def getTripleSubjectType(t:(String,String,String,String,String)) = t._4;

	/**
	 * Returns the object type of a triple with a given triple represented ina
	 * List<String>
	 * 
	 * @param t
	 *            A List<String> representing a triple
	 * @return the object type of the triple
	 */
	def getTripleObjectType(t:(String,String,String,String,String)) = t._5;

	/**
	 * @param xml
	 *            the xml document to parse
	 * @return the value of the element "status"
	 */
	def getSSAPMsgStatus(xml:String) = { // System.out.println("SSAP_XMLTools:getSSAPmsgStatus:xml content:\n"+xml);
		if (getParameterElement(xml, "name", "status") != null)
			getParameterElement(xml, "name", "status").getValue;
		else
			null;
	}

	def getSSAPMsgIndicationSequence(xml:String) = { // System.out.println("SSAP_XMLTools:getSSAPmsgStatus:xml content:\n"+xml);
		if (getParameterElement(xml, "name", "ind_sequence") != null)
			getParameterElement(xml, "name", "ind_sequence").getValue;
		else
			null;
	}

	/**
	 * Make the SELECT Sparql query SSAP message
	 * 
	 * @param query_string
	 *            the Sparql query to be performed
	 * @return a string representing the SSAP message to be sent to the SIB to
	 *         perform a Sparql query
	 **/
	def querySparql(query:String) = {
		transactionID+=1	//FIXME MAYBE
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>QUERY</transaction_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
				"</space_id><parameter name = \"type\">sparql</parameter><parameter name = \"query\">" +
				//"<![CDATA[" +
				correctEntityReferences(query) +
				//"]]>" +
				"</parameter></SSAP_message>";

	}

	/**
	 * This method corrects the 5 predefined entity references in XML which may
	 * occur in the sparql query string
	 * 
	 * @param query:
	 *            the Sparql query to be transformed
	 * @return the query with correct substitution of the xml entities
	 * 
	 */
	def correctEntityReferences(query:String) = query.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("'", "&apos;").replace("\"", "&quot;");

	/**
	 * Make the SSAP message to be sent to the SIB to perform Sparql queries in
	 * SIBs supporting it
	 * 
	 * @param insGraph
	 *            graph to be inserted
	 * @param remGraph
	 *            graph to be removed
	 * @return SSAP message to be sent to the SIB to support Sparql queries in
	 *         SIBs supporting it
	 */
	def updateSparql(sparqlUpdate:String) = {
		transactionID+=1	//FIXME MAYBE
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>UPDATE</transaction_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
				"</space_id><parameter name = \"insert_graph\" encoding = \"Sparql-UPDATE\">" +
				//"<![CDATA[" +
				correctEntityReferences(sparqlUpdate) +
				//"]]>" +
				"</parameter><parameter name = \"confirm\">TRUE</parameter></SSAP_message>";
	}

	/**
	 * 
	 * @param query
	 *            the persistent sparql update query
	 * @return SSAP message to be sent to the SIB to support Sparql queries in
	 *         SIBs supporting it
	 */
	def persistentUpdate(query:String) = {
		transactionID+=1	//FIXME MAYBE
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>PERSISTENT_UPDATE</transaction_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
				"</space_id><parameter name = \"query\" encoding = \"Sparql-UPDATE\">" +
				//"<![CDATA[" +
				correctEntityReferences(query) +
				//"]]>" +
				"</parameter><parameter name = \"confirm\">TRUE</parameter></SSAP_message>";
	}

	/**
	 * Make the SSAP message to be sent to the SIB to perform RDF/XML update in
	 * SIBs supporting it Optimized for red-SIB
	 * 
	 * @param insGraph
	 *            graph to be inserted
	 * @param remGraph
	 *            graph to be removed
	 * @return the SSAP message to be sent to the SIB to perform RDF/XML update
	 *         in SIBs supporting it
	 */

	def updateRDFXml(insGraph:String, remGraph:String) = {
		transactionID+=1	//FIXME MAYBE
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>UPDATE</transaction_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
				"</space_id><parameter name = \"insert_graph\" encoding = \"RDF-XML\">" +	// insert (NEW)
				//"<![CDATA[" +
				correctEntityReferences((insGraph.replaceAll("[^\\x20-\\x7e]", "??"))) +
				//"]]>" +
				"</parameter><parameter name = \"remove_graph\" encoding = \"RDF-XML\">" +	// remove (OLD)
				//"<![CDATA[" +
				correctEntityReferences((remGraph.replaceAll("[^\\x20-\\x7e]", "??"))) +
				//"]]>" +
				"</parameter><parameter name = \"confirm\">TRUE</parameter></SSAP_message>";
	}

	/**
	 * Make the SSAP message to be sent to the SIB to perform RDF/XML update in
	 * SIBs supporting it Optimized for OSGI SIB
	 * 
	 * @param insGraph
	 *            graph to be inserted
	 * @param remGraph
	 *            graph to be removed
	 * @return the SSAP message to be sent to the SIB to perform RDF/XML update
	 *         in SIBs supporting it
	 */

	def updateRDFXml2(insGraph:String, remGraph:String) = {
		transactionID+=1	//FIXME MAYBE
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>UPDATE</transaction_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
				"</space_id><parameter name = \"insert_graph\" encoding = \"RDF-XML\"><![CDATA[" +
				insGraph.replaceAll("[^\\x20-\\x7e]", "?") + "]]></parameter><parameter name = \"remove_graph\" encoding = \"RDF-XML\"><![CDATA[" +	// insert (NEW)
				remGraph.replaceAll("[^\\x20-\\x7e]", "?") + "]]></parameter><parameter name = \"confirm\">TRUE</parameter></SSAP_message>";		// remove (OLD)
	}

	/**
	 * Make the SSAP message to be sent to the SIB to perform RDF/XML insert in
	 * SIBs supporting it
	 * 
	 * @param graph
	 *            the graph to be inserted
	 * @return the SSAP message to be sent to the SIB to perform RDF/XML insert
	 *         in SIBs supporting it. This is optimized for red-SIB
	 */
	def insertRDFXml(graph:String) = {
		transactionID+=1
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>INSERT</transaction_type><transaction_id>" +
			transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
			"</space_id><parameter name=\"insert_graph\"  encoding=\"RDF-XML\">" +
				//"<![CDATA[" +
				correctEntityReferences(graph.replaceAll("[^\\x20-\\x7e]", "?")) +
				//"]]>" +
				"</parameter><parameter name = \"confirm\">TRUE</parameter></SSAP_message>";
	}

	/**
	 * Make the SSAP message to be sent to the SIB to perform RDF/XML insert in
	 * SIBs supporting it
	 * 
	 * @param graph
	 *            the graph to be inserted
	 * @return the SSAP message to be sent to the SIB to perform RDF/XML insert
	 *         in SIBs supporting it optimized for OSGI SIB
	 */
	def insertRDFXml2(graph:String) = {
		transactionID+=1
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>INSERT</transaction_type><transaction_id>" +
			transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
			"</space_id><parameter name=\"insert_graph\"  encoding=\"RDF-XML\"><![CDATA[" + graph.replaceAll("[^\\x20-\\x7e]", "?") +
			"]]></parameter><parameter name = \"confirm\">TRUE</parameter></SSAP_message>";
	}

	/**
	 * Make the SSAP message to be sent to the SIB to perform RDF/XML remove in
	 * SIBs supporting it
	 * 
	 * @param graph
	 *            the graph to be removed
	 * @return the SSAP message to be sent to the SIB to perform RDF/XML remove
	 *         in SIBs supporting it optimized for red-SIB
	 */
	def removeRDFXml(graph:String) = {
		transactionID+=1
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>REMOVE</transaction_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
				"</space_id><parameter name=\"remove_graph\"  encoding=\"RDF-XML\">" +
				//"<![CDATA[" +
				correctEntityReferences(graph.replaceAll("[^\\x20-\\x7e]", "??")) +
				//"]]>" +
				"</parameter><parameter name = \"confirm\">TRUE</parameter></SSAP_message>";
	}

	/**
	 * Make the SSAP message to be sent to the SIB to perform RDF/XML remove in
	 * SIBs supporting it
	 * 
	 * @param graph
	 *            the graph to be removed
	 * @return the SSAP message to be sent to the SIB to perform RDF/XML remove
	 *         in SIBs supporting it optimized for OSGI-SIB
	 */
	def removeRDFXml2(graph:String) = {
		transactionID+=1
		"<SSAP_message><message_type>REQUEST</message_type><transaction_type>REMOVE</transaction_type><transaction_id>" +
				transactionID + "</transaction_id><node_id>" + nodeID + "</node_id><space_id>" + smartSpaceName +
				"</space_id><parameter name=\"remove_graph\"  encoding=\"RDF-XML\"><![CDATA["+ graph.replaceAll("[^\\x20-\\x7e]", "?") +
				"]]></parameter><parameter name = \"confirm\">TRUE</parameter></SSAP_message>";
	}

	/**
	 * Method to obtain an object representing the response to a Sparql query
	 * starting from the SSAP message including it
	 * 
	 * @param xml
	 *            the SSAP message received by the SIB and containing a Sparql
	 *            response XML document
	 * @return a SSAP_sparql_response object containing the results of the query
	 *         performed
	 */
	def getSparqlQueryResults(xml:String) = SSAPSparqlResponse.fromResponse(xml);

	/**
	 * Method to obtain an object representing the response to a Sparql query
	 * representing the new results of a Sparql subscription
	 * 
	 * @param xml
	 *            indication sent by the SIB
	 * @return an object representing the response to a Sparql query
	 *         representing the new results of a Sparql subscription
	 */
	def getSparqlIndicationNewResults(xml:String) = {
		if (xml == null)
			throw new IllegalArgumentException("XML message is null");

		val doc = builder.build(new ByteArrayInputStream(xml.getBytes));
		if (doc == null)
			throw new IllegalArgumentException("doc is null");

		val root = doc.getRootElement;
		root.getChildren("parameter", root.getNamespace).asScala.find(_.getAttributeValue("name").equalsIgnoreCase("new_results")).getOrElse(throw new Exception("parameter(results) not found!")).getChildren.asScala.find(_.getName=="sparql").map(SSAPSparqlResponse.fromResponseElement).getOrElse(null);
	}

	/**
	 * Method to obtain an object representing the response to a Sparql query
	 * representing the obsolete results of a Sparql subscription
	 * 
	 * @param xml
	 *            indication sent by the SIB
	 * @return an object representing the response to a Sparql query
	 *         representing the new obsolete results of a Sparql subscription
	 */
	def getSparqlIndicationObsoleteResults(xml:String) = {
		if (xml == null)
			throw new IllegalArgumentException("XML message is null");

		val doc = builder.build(new ByteArrayInputStream(xml.getBytes));
		if (doc == null)
			throw new IllegalArgumentException("doc is null");

		val root = doc.getRootElement;
		root.getChildren("parameter", root.getNamespace).asScala.find(_.getAttributeValue("name").equalsIgnoreCase("obsolete_results")).getOrElse(throw new Exception("parameter(results) not found!")).getChildren.asScala.find(_.getName=="sparql").map(SSAPSparqlResponse.fromResponseElement).getOrElse(null);
	}

	def isResponseConfirmed(response:SIBResponse) = response.status equalsIgnoreCase "m3:success";

}
