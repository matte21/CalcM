package sofia_kp.scala

import java.io._;
import java.net._;
import java.util.UUID;
import scala.collection._;
import scala.collection.mutable.Buffer;
import scala.io._;

object KPICore {
	/**Error message code list*/
	private[sofia_kp] val ERR_NO_ERROR = 0;
	private[sofia_kp] val ERR_CONNECTED = 1;
	private[sofia_kp] val ERR_UNKNOWN_HOST = -2;
	private[sofia_kp] val ERR_IO_EXCEPTION = -3;

	private[sofia_kp] val ERR_CONNECTION_CLOSE = 4;
	private[sofia_kp] val ERR_EXC_CLOSE_CONN = -5;

	private[sofia_kp] val ERR_MSG_SENT = 6;
	private[sofia_kp] val ERR_MSG_SENT_EXC_CONN = -7;
	private[sofia_kp] val ERR_MSG_SENT_CONN_UNAVAILABLE = -8;
	private[sofia_kp] val ERR_RECEIVE_FAIL = -9;
	private[sofia_kp] val ERR_SOCKET_TIMEOUT = -10;
	private[sofia_kp] val ERR_PARAMETER_NULL = -11;
	private[sofia_kp] val ERR_SUBSCRIPTION_DONE = 12;
	private[sofia_kp] val ERR_SUBSCRIPTION_NOT_DONE = -13;

	private[sofia_kp] val ERR_INSERT_PROTECTION_FAIL = -14;
	private[sofia_kp] val ERR_REMOVE_PROTECTION_FAIL = -15;

	/**Error message explanation*/
	private[sofia_kp] val ERR_MSG = Array( "@NO ERROR", "@CONNECTED", "@ERR UNKNOWN HOST", "@ERR IO EXCEPTION"
			, "@CONNECTION CLOSE", "@ERR EXC CLOSE CONN"
			, "@MSG SENT", "@ERR MSG SENT EXC CONN", "@ERR MSG SENT CONN UNAVAILABLE", "@ERR RECEIVE FAIL", "@ERR SOCKET TIMEOUT", "@ERR PARAMETER NULL"
			, "@SUBSCRIPTION DONE", "@ERR SUBSCRIPTION NOT DONE", "@ERR INSERT PROTECTION FAIL", "@ERR REMOVE PROTECTION FAIL");
}

import KPICore._;

class KPICore(val host:String, val port:Int, val smartSpaceName:String) extends KPIC with KPICSubscribeHandler {
	def this() = this("", 0, "");

	// All the necessary stuff to handle the communication with the SIB
	private var kpSocket = null:Socket;
	private var out = null:PrintWriter;
	private var in = null:BufferedReader;
	private var is = null:InputStream;

	var protocolVersion = 0;

	private val SOCKET_TIMEOUT_DELAY = 10000;

	private var _nodeID = UUID.randomUUID toString;
	/**SSAP specification protocol element*/
	def nodeID = _nodeID;
	/**Set the node ID
	 * @param newNodeID */
	def nodeID_=(newNodeID:String) = {
		_nodeID = newNodeID;
		_xmlTools = new SSAPXMLTools(newNodeID, null, SSAPXMLTools.ANYURI);
	}
	
	private var _xmlTools = new SSAPXMLTools(nodeID, smartSpaceName, SSAPXMLTools.ANYURI);
	/**SSAP tools to handle SSAP messages*/
	def xmlTools = _xmlTools

	private val subscriptions = mutable.Map[String,Subscription]();
	
	/**Constants for use of protection at triple level. their use is currenlty not fully supported*/
	private val ARNameSpace = "http://ProtectionOntology.org";
	private val ARProperty = ARNameSpace + "#Has_Access_Restriction"; // FIXME This will be changed (AR = access restriction)
	private val AROwner = ARNameSpace + "#Has_Owner"; // FIXME This will be changed (AR = access restriction)
	private val ARTarget = ARNameSpace + "#Has_Target"; // FIXME This will be changed (AR = access restriction)

	/**This variable store the last error message code. Users can use this code to understand what occurs. Negative value means ERROR!!!*/
	private var kpErrorID = 0;

	private var printErr = false;
	private var printDebug = false;

	/**print msg if error printing is enabled
	 * @param msg*/
	private def errPrint(msg:String) {
		if (printErr)
			println(msg);
	}

	/**Print msg if debug is enabled
	 * @param msg*/
	private def debPrint(msg:String) {
		if (printDebug)
			println(msg);
	}

	def enableErrorMessage() = printErr = true;
	def enableDebugMessage() = printDebug = true;
	def disableErrorMessage() = printErr = false;
	def disableDebugMessage() = printDebug = false;

	/**Establish a socket connection to the SIB
	 * @return an error code */
	private[sofia_kp] def openConnect() = {
		try {
			kpSocket = new Socket(host, port);
			kpSocket.setKeepAlive(true); // TO TEST WITH WINDOWS
			out = new PrintWriter(kpSocket.getOutputStream, true);
			is = kpSocket.getInputStream;
			in = new BufferedReader(new InputStreamReader(is));
			ERR_CONNECTED;
		} catch {
		case e:UnknownHostException =>
			System.err.println("Don't know about host");
			ERR_UNKNOWN_HOST;
		case e:IOException =>
			System.err.println("Couldn't get I/O for the connection");
			ERR_IO_EXCEPTION;
		}
	}
	
	/**Send a pre-formed XML message to the SIB
	 * @param msg the string representation of the XML message to send. null value are not allowed.
	 * @return an error code */
	private[sofia_kp] def send(msg:String) = {
		if (kpSocket.isOutputShutdown)
			ERR_MSG_SENT_CONN_UNAVAILABLE;
		else {
			out.println(msg);
			try {
				if (msg.indexOf("SUBSCRIBE") < 0) {
					/* debPrint("[ATTENTION! THE FOLLOWING OPERATION IS NOT PERFORMED DUE TO BE ABLE TO USE A SSH TUNNEL]\n "
					 * + "[REF:java:send(String msg){}]\n this.kpSocket.shutdownOutput();");*/
					 kpSocket.shutdownOutput();
				} else
					debPrint("\n*** KpCore:send:shutdownOutput:OPERATION_NOT_TO_BE_DONE:this.kpSocket.shutdownOutput() \n\nSSAP MSG:" + msg);
				ERR_MSG_SENT;
			} catch {
			case e:Exception =>
				errPrint("KpCore:send:shutdownOutput:EXCEPTION:" + e);
				ERR_MSG_SENT_EXC_CONN;
			}
		}
	}
	
	/**Close the socket connection with the SIB
	 * @return an error code */
	private[sofia_kp] def closeConnection() = {
		try {
			out.close();
			in.close();
			kpSocket.close();
			ERR_CONNECTION_CLOSE;
		} catch {
		case e:Exception =>
			errPrint("KpCore:closeConnection:Exception:\n" + e);
			ERR_EXC_CLOSE_CONN;
		}
	}
	
	/**Method that wait until a message is received from the SIB
	 * @return a string representation of the XML message received from the SIB. 
	 * 		A null value means that an error occurs. In this case, check the 
	 * 		error state with the functions: getErrMess, getErrID
	 * @throws java.net.SocketException*/
	private[sofia_kp] def receive() = {
		var ret=null;
		kpSocket.setSoTimeout(SOCKET_TIMEOUT_DELAY);
		try {
			readByteXByteSIBmsg();
		}
		catch {
		case e:Exception =>
			kpErrorID=ERR_SOCKET_TIMEOUT;
			null;
		}
	}
	// ---------------------------------------------------
	/**Reads from the socket connected with the SIB
	 * @return the String read */
	private[sofia_kp] def readByteXByteSIBmsg():String = {
		var msg = "";
		try{
			msg = Source.fromInputStream(is).mkString;
			if (msg.contains("<SSAP_message>") && msg.contains("</SSAP_message>")){ // The first message is not an event but just the confirmation message!!!
				if (xmlTools.isSubscriptionConfirmed(msg)){
					//KP_ERROR_ID=ERR_SUBSCRIPTION_DONE;
					//startEventHandlerThread(kpSocket,in,out);
					return msg;
				}
				else
					debPrint("KpCore:readByteXByteSIBmsg:SSAP message recognized");
			}
			debPrint("KpCore:readByteXByteSIBmsg:READ LOOP TERMINATED");
			closeConnection();
		} catch {
		case e:Exception =>
			errPrint("KPICore:readByteXByteSIBmsg:Exception on EVENT HANDLER:RECEIVE:\n" + e);
			kpErrorID = ERR_SOCKET_TIMEOUT;
		}
		return msg;
	}
	
	def sendSSAPMsgOneWay(msg:String) {
		debPrint("KpCore:message to send:_" + msg.replace("\n", "") + "_");
		debPrint("KpCore:SSAP:Open connection...");
		var err = openConnect();
		if (err < 0) {
			errPrint("KpCore:SSAP:ERROR:" + ERR_MSG(err * -1));
			kpErrorID = err;
		} else
			debPrint("KpCore:SSAP:" + ERR_MSG(err));

		debPrint("KpCore:SSAP:Send the message...");
		err = send(msg);
		if (err < 0) {
			errPrint("KpCore:SSAP:ERROR:" + ERR_MSG(err * -1));
			kpErrorID = err;
		} else
			debPrint("KpCore:SSAP:" + ERR_MSG(err));
	}
	
	/**The SSAP protocol is based on some operation to do atomically:
	 * <ul>
	 * <li>open the connection</li>
	 * <li>send a message</li>
	 * <li>wait for the answer</li>
	 * </ul>
	 * This method encapsulate all this operation<br><br>
	 * Send a pre-formed XML message to the SIB
	 * @param msg the string representation of the XML message to send. null value are not allowed.
	 * @return a string representation of the XML message received from the SIB. A null value means that 
	 * 		an error occurs. In this case, check the error state with the functions: getErrMess, getErrID */
	private[sofia_kp] def sendSSAPMsg(msg:String):String = {
		debPrint("KpCore:message to send:_"+msg.replace("\n","")+"_");
		debPrint("KpCore:SSAP:Open connection...");
		var ret="";
		var err = openConnect();
		if (err < 0) {
			errPrint("KpCore:SSAP:ERROR:" + ERR_MSG(err * -1));
			kpErrorID = err;
			return null;
		}
		debPrint("KpCore:SSAP:" + ERR_MSG(err));
		debPrint("KpCore:SSAP:Send the message...");
		err = send(msg);
		if (err < 0) {
			errPrint("KpCore:SSAP:ERROR:" + ERR_MSG(err * -1));
			kpErrorID = err;
			return null;
		}
		debPrint("KpCore:SSAP:" + ERR_MSG(err));
		debPrint("KpCore:SSAP:Read the answer...");
		if (msg.indexOf("<transaction_type>UNSUBSCRIBE</transaction_type>") < 0)
			try {
				ret = receive();
				debPrint("KpCore:SSAP:answer:" + "ok _" + ret.replace("\n","") + "_\n");
			} catch {
			case e:Exception =>
				err = kpErrorID;
				if (err < 0)
					errPrint("KpCore:SSAP:ERROR:" + ERR_MSG(err * -1));
				else {
					err = ERR_RECEIVE_FAIL;
					if (err < 0)
						errPrint("KpCore:SSAP:ERROR:" + ERR_MSG(err * -1));
				}
				errPrint("EXCEPTION: " + e);
				e.printStackTrace();
				kpErrorID = err;
				return null;
			}
		else
			debPrint("KpCore:SSAP:Unsubscription Request:no answer expected:"+"ok"+"\n");
		debPrint("KpCore:SSAP:Close connection...");
		err = closeConnection();
		if (err < 0){
			errPrint("KpCore:SSAP:ERROR:" + ERR_MSG(err * -1));
			kpErrorID = err;
			return null;
		} else
			kpErrorID = ERR_NO_ERROR;
		/*if (kpErrorID >= 0)
			kpErrorID = err;*/
		return ret;
	}
	
	/**This method return the string representation of the last operation result. 
	 * It is possible to know the final state of each operation by calling this method.
	 * @return a string explanation message for the last error occurred */
	private[sofia_kp] def errMess = if (kpErrorID < 0) "ERROR MESSAGE:" + ERR_MSG(kpErrorID * -1) else "SERVICE NOTE:" + ERR_MSG(kpErrorID);
	
	/**This method return the error ID of the last operation result.
	 * @return return the ID for the last error occurred, negative value means error */
	private[sofia_kp] def errID = kpErrorID;
	
	/* ***************************************************
	 * \
	 * 
	 * Follow the operation available with the SIB
	 * 
	 * \
	 ****************************************************/
	override def join() = {
		debPrint("\n[JOIN]___________________________________");
		new SIBResponse(sendSSAPMsg(xmlTools.join()));
	}
	
	override def leave() = {
		debPrint("\n[LEAVE]___________________________________");
		unsubscribe();
		new SIBResponse(sendSSAPMsg(xmlTools.leave()));
	}
	
	override def queryRDF(triples:Seq[(String,String,String,String,String)]) = {
		debPrint("\n[QUERY RDF]___________________________________");
		new SIBResponse(sendSSAPMsg(xmlTools.queryRDF(triples)));
	}

	override def insert(triples:Seq[(String,String,String,String,String)]) = {
		debPrint("\n[INSERT]___________________________________");
		new SIBResponse(sendSSAPMsg(xmlTools.insert(triples)));
	}
	
	override def remove(triples:Seq[(String,String,String,String,String)]) = {
		debPrint("\n[REMOVE]___________________________________");
		new SIBResponse(sendSSAPMsg(xmlTools.remove(triples)));
	}
	
	/**Perform a SPARQL update on SIBs supporting it
	 * @param sparqlUpdate	a SPARQL update query
	 * @return the SIB answer
	 * @Todo This method currently supports SPARQL update for SIB 0.9 only with protocol version = 0 (default) */
	def updateSparql(sparqlUpdate:String) = {
		debPrint("\n[UPDATE]___________________________________");
		if (protocolVersion == 0)
			new SIBResponse(sendSSAPMsg(xmlTools.querySparql(sparqlUpdate)));
		else
			new SIBResponse(sendSSAPMsg(xmlTools.updateSparql(sparqlUpdate)));
	}
	
	override def update(newTripleList: Seq[(String, String, String, String, String)],oldTripleList: Seq[(String, String, String, String, String)]) = {
		debPrint("\n[UPDATE]___________________________________");
		new SIBResponse(sendSSAPMsg(xmlTools.update(newTripleList, oldTripleList)));
	}
	
	/**Perform a persistent sparql update, acting like a rule on the store */
	def persistentUpdate(query:String) = {
		debPrint("\n[PERSISTENT UPDATE]___________________________________");
		new SIBResponse(sendSSAPMsg(xmlTools.persistentUpdate(query)));
	}
	
	/**Remove a persistent update
	 * @param updateID	the ID of the persistent update
	 * @return the SIB response message */
	def cancelPersistentUpdate(updateID:String) = {
		debPrint("\n[CANCEL PERSISTENT UPDATE]___________________________________");
		new SIBResponse(sendSSAPMsg(xmlTools.cancelPersistentUpdate(updateID)));
	}
	
	override def subscribeRDF(handler:KPICSubscribeHandler, triples:Seq[(String,String,String,String,String)]) = {
		debPrint("\n[SUBSCRIBE RDF]___________________________________");
		subscribe(xmlTools.subscribeRDF(triples), handler);
	}
	
	override def subscribeSparql(query:String, handler:KPICSubscribeHandler) = {
		debPrint("\n[SUBSCRIBE SPARQL]___________________________________");
		subscribe(xmlTools.subscribeSparql(query), handler);
	}
	
	/**Private method to start the subscription event handler
	 * @param message	SSAP message to send to the SIB
	 * @param handler	The event handler
	 * @return the SIB answer to the subscription request, or null in case of error */
	private def subscribe(message:String, handler:KPICSubscribeHandler):SIBResponse = {
		debPrint("KpCore:subscribe method");
		if (handler == null){
			kpErrorID = ERR_PARAMETER_NULL;
			errPrint("EVENT HANDLER IS NULL!!!");
			return null;
		}
		var msg = message;
		var ret = 0;
		debPrint("KpCore:SSAP:XML MESSAGE:\n" + msg);
		debPrint("KpCore:SSAP:Open connection...");
		ret = openConnect();
		if (ret != ERR_CONNECTED){
			kpErrorID = ret;
			errPrint("ERROR:subscribeRDF:connection error:" + errMess);
			return null;
		}
		debPrint("KpCore:SSAP:Send message...");
		ret = send(msg);
		if (ret != ERR_MSG_SENT){
			kpErrorID = ret;
			errPrint("ERROR:subscribeRDF:send error:" + errMess);
			return null;
		}
		debPrint("KpCore:SSAP:Message Sent...");
		// ****************************
		val buffsize = 4 * 1024;
		var builder = new StringBuilder();
		var buffer = new Array[Char](buffsize);
		msg = "";
		var charRead = 0;
		try{
			charRead = in.read(buffer, 0, buffer.length);
			while (charRead != -1){
				builder.append(buffer.subSequence(0, charRead));
				//println("Into while msg=" + builder.toString);
				msg = builder toString;
				//msg=Source.fromInputStream(is).mkString;	//Shortcut, but sometimes doesn't work fine with sockets
				if ((msg contains "<SSAP_message>") && (msg contains "</SSAP_message>")) // The first message is not an event but just the confirmation message!!!
					if (xmlTools.isSubscriptionConfirmed(msg)){
						kpErrorID = ERR_SUBSCRIPTION_DONE;
						kpSocket.setKeepAlive(true);
						val r = new SIBResponse(msg);
						subscriptions += r.subscriptionID -> new Subscription(kpSocket, handler);
						return r;
					}
					else
						println("[90] UNKNOW MESSAGE:" + msg);
				charRead = in.read(buffer, 0, buffer.length);
			}
			debPrint("KpCore:readByteXByteSIBmsg:READ LOOP TERMINATED");
			closeConnection();
		} catch {
		case e:Exception =>
			errPrint("KPICore:readByteXByteSIBmsg:Exception on EVENT HANDLER:RECEIVE:\n" + e);
			kpErrorID = ERR_SOCKET_TIMEOUT;
		}
		kpErrorID = ERR_SUBSCRIPTION_NOT_DONE;
		debPrint("KpCore:SSAP:Message received:(" + msg + ")");
		return new SIBResponse(msg);
	}
	
	/**Perform the UNSUBSCRIBE procedure for every active subscription.<br>
	 * Check the error state with the functions getErrMess, getErrID
	 * @return the answer message from the SIB */
	def unsubscribe():Unit = subscriptions.foreach(kv=>unsubscribe(kv._1));
	
	override def unsubscribe(subscriptionID:String) = {
		debPrint("\n[UNSUBSCRIBE]___________________________________");
		if (subscriptions contains subscriptionID){
			sendSSAPMsgOneWay(xmlTools.unsubscribe(subscriptionID));
			subscriptions(subscriptionID).stop();
			subscriptions -= subscriptionID;
			// return new SIBResponse(sendSSAPMsg(xmlTools.unsubscribe(subscriptionID) ));
			new SIBResponse("UNSUB", null, subscriptionID);	//workaround because there is no confirmation message in SSAP for unsubscribe
		} else {
			kpErrorID = ERR_PARAMETER_NULL;
			errPrint("SUBSCRIPTION NOT DONE!!!");
			null;
		}
	}
	
	override def insertProtection(entityI:String, properties:String*) = {
		val protectionEntity = "http://" + UUID.randomUUID;
		debPrint("KpCore:insertProtection:Praparing all the protection triples...");
		val triples = Buffer[(String,String,String,String,String)]();
		triples += ((entityI, ARProperty, protectionEntity, "URI", "URI"));
		triples += ((protectionEntity, AROwner, nodeID, "URI", "URI"));
		debPrint("KpCore:insertProtection:For loop on all triples to insert...");
		triples ++= properties.map((protectionEntity, ARTarget, _, "URI", "literal"));
		debPrint("KpCore:insertProtection:Insert triples...");
		val out = insert(triples);
		val ack = xmlTools.isResponseConfirmed(out);
		debPrint("KpCore:insertProtection:SIB message response:\n" + out + "\n");
		debPrint("Insert confirmed:" + (if (ack) "YES" else "NO"));
		kpErrorID = if (ack) ERR_NO_ERROR else ERR_INSERT_PROTECTION_FAIL;
		if (kpErrorID < 0)
			errPrint("KpCore:insertProtection:ERROR:" + ERR_MSG(kpErrorID * -1));
		out;
	}
	
	override def removeProtection(entityI:String, properties:String*) = {
		val protectionEntity = "http://" + UUID.randomUUID;
		debPrint("KpCore:removeProtection:Praparing all the protection triples...");
		val triples = Buffer[(String,String,String,String,String)]();
		triples += ((entityI, ARProperty, protectionEntity, "URI", "URI"));
		triples += ((protectionEntity, AROwner, nodeID, "URI", "URI"));
		debPrint("KpCore:removeProtection:For loop on all triples to remove...");
		triples ++= properties.map((protectionEntity, ARTarget, _, "URI", "literal"));
		debPrint("KpCore:removeProtection:Remove triples...");
		val out = remove(triples);
		val ack = xmlTools.isResponseConfirmed(out);
		debPrint("KpCore:removeProtection:SIB message response:\n" + out + "\n");
		debPrint("Remove confirmed:" + (if (ack) "YES" else "NO"));
		kpErrorID = if (ack) ERR_NO_ERROR else ERR_REMOVE_PROTECTION_FAIL;
		if (kpErrorID < 0)
			errPrint("KpCore:removeProtection:ERROR:" + ERR_MSG(kpErrorID * -1));
		out;
	}
	
	override def querySparql(query:String) = {
		debPrint("\n[QUERY SPARQL]___________________________________");
		new SIBResponse(sendSSAPMsg(xmlTools.querySparql(query)));
	}
	
	/**Remove specified in RDF-XML
	 * @param graph
	 * @return SIB response */
	def removeRDFXml(graph:String) = {
		debPrint("\n[REMOVE_RDF-XML]___________________________________");
		if (protocolVersion == 0)
			new SIBResponse(sendSSAPMsg(xmlTools.removeRDFXml(graph)));
		else
			new SIBResponse(sendSSAPMsg(xmlTools.removeRDFXml(graph)));
	}

	/**Insert specified in RDF-XML
	 * @param graph
	 * @return SIB response */
	def insertRDFXml(graph:String) = {
		debPrint("\n[INSERT_RDF-XML]___________________________________");
		debPrint(xmlTools.insertRDFXml(graph));
		if (protocolVersion == 0)
			new SIBResponse(sendSSAPMsg(xmlTools.insertRDFXml(graph)));
		else
			new SIBResponse(sendSSAPMsg(xmlTools.insertRDFXml2(graph)));
	}

	/**Update specified in RDF-XML
	 * @param insGraph
	 * @param remGraph
	 * @return SIB response */
	def updateRDFXml(insGraph:String, remGraph:String) = {
		debPrint("\n[UPDATE]___________________________________");
		if (protocolVersion == 0)
			new SIBResponse(sendSSAPMsg(xmlTools.updateRDFXml(insGraph, remGraph)));
		else
			new SIBResponse(sendSSAPMsg(xmlTools.updateRDFXml2(insGraph, remGraph)));
	}
	override def kpicExceptionEventHandler(SocketException:Throwable) {}
	override def kpicRDFEventHandler(newTriples:Seq[(String,String,String,String,String)], oldTriples:Seq[(String,String,String,String,String)], indSequence:String, subID:String) {}
	override def kpicSparqlEventHandler(newResults:SSAPSparqlResponse, oldResults:SSAPSparqlResponse, indSequence:String, subID:String) {}
	override def kpicUnsubscribeEventHandler(subID:String) {}
}