package sofia_kp.scala

trait KPICSubscribeHandler {
	def kpicRDFEventHandler(newTriples:Seq[(String,String,String,String,String)], oldTriples:Seq[(String,String,String,String,String)], indSequence:String, subID:String);

	def kpicSparqlEventHandler(newResults:SSAPSparqlResponse, oldResults:SSAPSparqlResponse, indSequence:String, subID:String);

	def kpicUnsubscribeEventHandler(subID:String);

	def kpicExceptionEventHandler(SocketException:Throwable);

}