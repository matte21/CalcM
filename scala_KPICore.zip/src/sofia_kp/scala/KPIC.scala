package sofia_kp.scala

trait KPIC {
	/* ***************************************************
	 * \
	 * 
	 * Follow the operation available with the SIB
	 * 
	 * \
	 ****************************************************/
	/**Perform the JOIN procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID
	 * @return the answer message from the SIB */
	def join():SIBResponse;

	/**Perform the LEAVE procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID
	 * @return the answer message from the SIB */
	def leave():SIBResponse;

	/**Perform the RDF Query procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID
	 * @param triples	Each element contains:
	 * 		<ul>
	 * 		<li>the subject</li>
	 * 		<li>the predicate</li>
	 * 		<li>the object</li>
	 * 		<li>the subject type ("uri"|"literal")</li>
	 * 		<li>the object type ("uri"|"literal")</li>
	 * 		</ul><br>
	 * 		<p>A null value for subject, predicate or object means any value</p>
	 * @return the answer message from the SIB */
	def queryRDF(triples:Seq[(String,String,String,String,String)]):SIBResponse;
	/**Perform the RDF Query procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID
	 * @param triples	Each element contains:
	 * 		<ul>
	 * 		<li>the subject</li>
	 * 		<li>the predicate</li>
	 * 		<li>the object</li>
	 * 		<li>the subject type ("uri"|"literal")</li>
	 * 		<li>the object type ("uri"|"literal")</li>
	 * 		</ul><br>
	 * 		<p>A null value for subject, predicate or object means any value</p>
	 * @return the answer message from the SIB */
	def queryRDF(triple:(String,String,String,String,String), triples:(String,String,String,String,String)*):SIBResponse = queryRDF(triple +: triples);

	/**Perform the INSERT procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID
	 * @param triples	Each element contains:
	 * 		<ul>
	 * 		<li>the subject</li>
	 * 		<li>the predicate</li>
	 * 		<li>the object</li>
	 * 		<li>the subject type ("uri"|"literal")</li>
	 * 		<li>the object type ("uri"|"literal")</li>
	 * 		</ul><br>
	 * 		<p>A null value for subject, predicate or object means any value</p>
	 * @return the answer message from the SIB */
	def insert(triples:Seq[(String,String,String,String,String)]):SIBResponse;
	/**Perform the INSERT procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID
	 * @param triples	Each element contains:
	 * 		<ul>
	 * 		<li>the subject</li>
	 * 		<li>the predicate</li>
	 * 		<li>the object</li>
	 * 		<li>the subject type ("uri"|"literal")</li>
	 * 		<li>the object type ("uri"|"literal")</li>
	 * 		</ul><br>
	 * 		<p>A null value for subject, predicate or object means any value</p>
	 * @return the answer message from the SIB */
	def insert(triple:(String,String,String,String,String), triples:(String,String,String,String,String)*):SIBResponse = insert(triple +: triples);

	/**Perform the REMOVE procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID
	 * @param triples	Each element contains:
	 * 		<ul>
	 * 		<li>the subject</li>
	 * 		<li>the predicate</li>
	 * 		<li>the object</li>
	 * 		<li>the subject type ("uri"|"literal")</li>
	 * 		<li>the object type ("uri"|"literal")</li>
	 * 		</ul><br>
	 * 		<p>A null value for subject, predicate or object means any value</p>
	 * @return the answer message from the SIB */
	def remove(triples:Seq[(String,String,String,String,String)]):SIBResponse;
	/**Perform the REMOVE procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID
	 * @param triples	Each element contains:
	 * 		<ul>
	 * 		<li>the subject</li>
	 * 		<li>the predicate</li>
	 * 		<li>the object</li>
	 * 		<li>the subject type ("uri"|"literal")</li>
	 * 		<li>the object type ("uri"|"literal")</li>
	 * 		</ul><br>
	 * 		<p>A null value for subject, predicate or object means any value</p>
	 * @return the answer message from the SIB */
	def remove(triple:(String,String,String,String,String), triples:(String,String,String,String,String)*):SIBResponse = remove(triple +: triples);

	/**Perform the UPDATE procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID.<br><br>
	 * Each element contains:
	 * <ul>
	 * <li>the subject</li>
	 * <li>the predicate</li>
	 * <li>the object</li>
	 * <li>the subject type ("uri"|"literal")</li>
	 * <li>the object type ("uri"|"literal")</li>
	 * </ul>
	 * A null value for subject, predicate or object means any value
	 * @param newTriple	New value to insert
	 * @param oldTriple	Old value to replace
	 * @return the answer message from the SIB */
	def update(newTriple:(String,String,String,String,String), oldTriple:(String,String,String,String,String)):SIBResponse = update(List(newTriple),List(oldTriple));

	/**Perform the UPDATE procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID.<br><br>
	 * Each element contains:
	 * <ul>
	 * <li>the subject</li>
	 * <li>the predicate</li>
	 * <li>the object</li>
	 * <li>the subject type ("uri"|"literal")</li>
	 * <li>the object type ("uri"|"literal")</li>
	 * </ul>
	 * A null value for subject, predicate or object means any value
	 * @param newTripleList	New values to insert
	 * @param oldTripleList	Old values to replace
	 * @return the answer message from the SIB */
	def update(newTripleList:Seq[(String,String,String,String,String)], oldTripleList:Seq[(String,String,String,String,String)]):SIBResponse;

	/**Perform the RDF SUBSCRIBE procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID.<br>
	 * @param handler	The event handler
	 * @param triples	Each element contains:
	 * 		<ul>
	 * 		<li>the subject</li>
	 * 		<li>the predicate</li>
	 * 		<li>the object</li>
	 * 		<li>the subject type ("uri"|"literal")</li>
	 * 		<li>the object type ("uri"|"literal")</li>
	 * 		</ul><br>
	 * A null value for subject, predicate or object means any value
	 * @return the answer message from the SIB */
	def subscribeRDF(handler:KPICSubscribeHandler, triples:Seq[(String,String,String,String,String)]):SIBResponse;
	/**Perform the RDF SUBSCRIBE procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID.<br>
	 * @param handler	The event handler
	 * @param triples	Each element contains:
	 * 		<ul>
	 * 		<li>the subject</li>
	 * 		<li>the predicate</li>
	 * 		<li>the object</li>
	 * 		<li>the subject type ("uri"|"literal")</li>
	 * 		<li>the object type ("uri"|"literal")</li>
	 * 		</ul><br>
	 * A null value for subject, predicate or object means any value
	 * @return the answer message from the SIB */
	def subscribeRDF(handler:KPICSubscribeHandler, triple:(String,String,String,String,String), triples:(String,String,String,String,String)*):SIBResponse = subscribeRDF(handler, triple +: triples);

	/**Perform the UNSUBSCRIBE procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID
	 * @return the answer message from the SIB */
	def unsubscribe(subscriptionID:String):SIBResponse;

	/**Perform the SPARQL-QUERY procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID
	 * @param query	The SPARQL query
	 * @return the answer message from the SIB */
	def querySparql(query:String):SIBResponse;
	
	/**Perform the SPARQL SUBSCRIBE procedure.<br>
	 * Check the error state with the functions getErrMess, getErrID.<br>
	 * @param query		The SPARQL query
	 * @param handler	The event handler
	 * @return the answer message from the SIB */
	def subscribeSparql(query:String, handler:KPICSubscribeHandler):SIBResponse;
	
	/**
	 * @param entity		Specify the entity which the protection must be applied
	 * @param properties	Entity's property list to protect
	 * @return the answer message from the SIB */
	def insertProtection(entity:String, properties:String*):SIBResponse;

	/**
	 * @param entity		Specify the entity on which the protection was applied
	 * @param properties	Entity's property list protected
	 * @return the answer message from the SIB */
	def removeProtection(entity:String, properties:String*):SIBResponse;
}