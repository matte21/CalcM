package sofia_kp.scala

import java.io._
import java.nio.charset._

import scala.collection.JavaConverters._
import scala.collection.mutable

import org.jdom2._
import org.jdom2.input._
import org.jdom2.output._
import org.xml.sax._

object SSAPSparqlResponse {
	private val VARNAME = 0;
	private val CATEGORY = 1;
	private val VALUE = 2;
	private val TYPE = 3;

	def fromResponseXML(xml:String) = {
		try {
			new SSAPSparqlResponse(loadXmlFromString(xml).getRootElement, null, false, false, false);
		} catch {
		case e:Exception =>
			System.err.println("EXCEPTION:");
			e.printStackTrace();
			null
		}
	}
	
	/**The constructor of the SSAP_sparql_response Class
	 * 
	 * each result in the SSAP sparql response message is saved as a List of
	 * String[]. Each element of this List represents the detail of the
	 * "binding" element: [name, category, value, type]. "name" is the binding
	 * name of the result element; "value" is the proper value of the result
	 * element; To understand the meaning of the category and type field, there
	 * is a classification of possible bindings:
	 *
	 * The value of a query variable "binding", which is an RDF Term, is
	 * included as the content of the binding as follows: category URI, for a
	 * binding element of the form: <binding><uri>U</uri></binding> category
	 * LITERAL, for a binding element of one of the forms:
	 * <binding><literal>S</literal></binding> (type SIMPLE, nothing added)
	 * <binding><literal xml:lang="L">S</literal></binding> (TYPE WLANG, the
	 * value of the attribute "xml:lang" is added)
	 * <binding><literal datatype="D">S</literal></binding> (TYPE WDATT, the
	 * value of the attribute "datatype" is added) category BNODE, for a binding
	 * element of the form <binding><bnode>I</bnode></binding> category UNBOUND,
	 * for an unbound variable (no binding element for that variable is included
	 * in the result element). In case of UNBOUND, BNODE or URI category, the
	 * "type" field is NOT present.
	 *
	 * @return This function returns all the results of the SSAP sparql response
	 *         message as a List<List<String[]>>.
	 */
	def fromResponse(ssapSparqlResponse:String) = {
		if (ssapSparqlResponse == null)
			throw new IllegalArgumentException("XML message is null");

		try {
			val rootParameterChildren = loadXmlFromString(ssapSparqlResponse).getRootElement.getChildren("parameter").asScala.filter(_.getAttributeValue("name") == "results").flatMap(_.getChildren asScala);
			
			// QUERY TYPE CONFIRM GRAPH (DESCRIBE/CONSTRUCT)
			val confirmGraph = rootParameterChildren.find(_.getName == "RDF");
			val (queryTypeConstructDescribe, resultGraph) = if (confirmGraph.isDefined) (true, confirmGraph.get) else (false, null);
			
			// QUERY TYPE SPARQL (SELECT/ASK)
			val sparql = rootParameterChildren.find(_.getName == "sparql");
			if (sparql.isDefined)
				new SSAPSparqlResponse(sparql.get, resultGraph, true, queryTypeConstructDescribe, true);
			else
				throw new Exception("sparql element not found");
		} catch {
		case e:SAXException =>
			System.err.println("SAX EXCEPTION");
			e.printStackTrace();
			null
		case e:IOException =>
			System.err.println("IO EXCEPTION");
			e.printStackTrace();
			null
		case e:Exception=>e.printStackTrace()
			null
		}
	}

	/**Constructor with a Jdom2 Document representing the response as input*/
	def fromResponseElement(ssapSparqlResponseElement:Element) = {
		try {
			new SSAPSparqlResponse(ssapSparqlResponseElement, null, false, false, true);
		} catch {
		case e:Exception =>
			System.err.println("EXCEPTION:");
			e.printStackTrace();
			null
		}
	}
	
	/**A simple XML parser from a string. Returns a Document which represents
	 * the root of the document tree.
	 * 
	 * @param xml
	 * @return the XML Document for the message received as a string
	 * @throws Exception
	 */
	private def loadXmlFromString(xml:String) = new SAXBuilder().build(new ByteArrayInputStream(xml.getBytes(Charset.forName("UTF-8"))));


	/**Builds the fields of SSAP_sparql_response starting from a string written
	 * in xml and accordin to the W3C xml schema for sparql responses of type
	 * select or ask
	 */
	def fromSparqlResponse(selectAskResponse:String) = {
		if (selectAskResponse == null)
			throw new IllegalArgumentException("XML message is null");

		try {
			new SSAPSparqlResponse(new SAXBuilder().build(new ByteArrayInputStream(selectAskResponse.getBytes)).getRootElement, null, false, false, false);
		} catch {
		case e:Exception =>
			System.err.println("EXCEPTION:");
			e.printStackTrace();
			null
		}
	}
	
	/**class to represent each field of a result*/
	class ResultCell private[SSAPSparqlResponse](cell:Array[String]){
		
		/**the variable name of the binding element */
		def name = if (cell != null) cell(VARNAME) else null;
	
		/**the value of the binding element*/
		def value = if (cell != null) cell(VALUE) else null;
	
		/**the category of the binding element ("uri", "literal", "bnode", "unbound")*/
		def category = if (cell != null) cell(CATEGORY) else null;
	
		/**the type of the binding element ("xml:lang" plus its value or "datatype" plus its value) in an unique string*/
		def Type = {	//type is a keyword so can't be used
			// return cell[3] containing the VALUE of the type (xml:lang = ..., or datatype=...)
			if (cell != null)
				if (cell(CATEGORY)=="literal")
					if (cell.length == 4)
						cell(TYPE);
					else {
						System.err.println("Sorry this cell is a simple \"literal\"");
						null;
					}
				else {
					System.err.println("Sorry this cell is not a \"literal\"");
					null;
				}
			else null;
		}
	
		/**the type name of the literal element ("xml:lang" or "datatype")*/
		def literalTypeName = {
			if (cell != null)
				if (cell(CATEGORY)=="literal")
					if (cell(TYPE) contains "xml:lang")
						"xml:lang";
					else if (cell(TYPE) contains "datatype")
						"datatype";
					else {
						System.err.println("Sorry this cell is neither a xml:lang nor a datatype");
						null;
					}
				else {
					System.err.println("Sorry this cell is not a \"literal\"");
					null;
				}
			else null;
		}
	
		/**the type value of the literal element (after "xml:lang" or "datatype")*/
		def literalTypeValue = {
			if (cell != null)
				if (cell(CATEGORY)=="literal")
					if (cell(TYPE) contains "xml:lang")
						cell(TYPE).split("xml:lang=")(1);
					else if (cell(TYPE) contains "datatype")
						cell(TYPE).split("dataype=")(1);
					else {
						System.err.println("Sorry this cell is neither a xml:lang nor a datatype");
						null;
					}
				else {
					System.err.println("Sorry this cell is not a \"literal\"");
					null;
				}
			else null;
		}
		
		/**the value of the binding element as an Int */
		def intValue = value toInt;
		
		/**the value of the binding element, restoring special chars */
		def stringValue = value.replaceAll("&lt;", "<").replaceAll("&gt;", ">").replaceAll("&apos;", "'").replaceAll("&quot;", "\"").replaceAll("&amp;", "&");
		
		/**the value of the binding element removing the namespace */
		def uriValueWithoutNS(nsm:NamespaceManager) = nsm.removeNamespace(value);
		
		/**the value of the binding element removing the namespace */
		def uriValueShortNS(nsm:NamespaceManager) = nsm.shortURI(value);
	}
}
import SSAPSparqlResponse._

/**This class represents the SSAP RESPONSE to a generic SPARQL query. This class
 * offers methods to extract and manage the results inside the response. This
 * class is coherent with the entire library project and uses java.util.List
 * instead of better performing ArrayList or similar A refactory of this library
 * is suggested.
 * 
 * The computation time is reduced: the instantiated object of this class loads
 * into memory the SSAP response as a string, AND the entire structure with the
 * results (which may be many). Thanks to the methods offered by the class, we
 * obtain the desired structures NOT at run time. This programming model looks
 * at the execution time, and can therefore have effects on occupation of space
 * in memory. */
class SSAPSparqlResponse private(ssapSparqlResponse:Element, resultGraph:Element, val isQueryTypeSelect:Boolean, val isQueryTypeConstruct:Boolean, checkUnbound:Boolean) {
	val (variableNames, linkHrefs, results, booleans) = {
		val responseElements = ssapSparqlResponse.getChildren.asScala.groupBy(_.getName toLowerCase);
		
		val headElementsAttributes = responseElements.getOrElse("head",List.empty).flatMap(_.getChildren asScala).flatMap(_.getAttributes asScala).groupBy(_.getName);
		val varNames = headElementsAttributes.getOrElse("name",List.empty).map(_.getValue):Seq[String];
		val linkRrefs = headElementsAttributes.getOrElse("href",List.empty).map(_.getValue):Seq[String];
		
		val sparqlResponseResults = responseElements.getOrElse("results",List.empty).flatMap(_.getChildren asScala).map(result=>{
			val singleResult = mutable.Buffer[ResultCell]();
			var varIndex = 0;
			for (binding <- result.getChildren asScala){
				var cellTemp = binding.getAttributes.asScala.filter(_.getName=="name").map(_.getValue);
				val bindingChilds = binding.getChildren.asScala.groupBy(_.getName toLowerCase);
				cellTemp ++=
					bindingChilds.getOrElse("uri",List.empty).flatMap(e=>List(e.getName, e.getValue)) ++=
					bindingChilds.getOrElse("bnode",List.empty).flatMap(e=>List(e.getName, e.getValue)) ++=
					bindingChilds.getOrElse("unbound",List.empty).map(_.getName) ++=
					bindingChilds.getOrElse("literal",List.empty).flatMap(e=>List(e.getName, e.getValue) ++ e.getAttributes.asScala.filter(a=>a.getQualifiedName=="xml:lang" || a.getQualifiedName=="datatype").map(a=>a.getQualifiedName + "=\"" + a.getValue + "\""));
				if (cellTemp.size < 3)
					cellTemp += null;
				val singleCell = cellTemp toArray;
				
				// Here we check if there are unbound variables omitted in the xml.
				// If this happens we put an unbound cell in our representation
				if (checkUnbound)
					while (singleCell(VARNAME) != varNames(varIndex)) {
						val dummyCell = new Array[String](3);
						dummyCell(VARNAME) = varNames(varIndex);
						dummyCell(CATEGORY) = "unbound";
						dummyCell(VALUE) = null;
						singleResult += new ResultCell(dummyCell);
						varIndex+=1;
					}
				
				// ADDING THE CELL TO SINGLE_RESULT
				singleResult += new ResultCell(singleCell);
				varIndex+=1;
			}
			singleResult toSeq
		}):Seq[Seq[ResultCell]];
		
		val booleans = responseElements.getOrElse("boolean",List.empty).map(_.getValue toBoolean):Seq[Boolean];
		
		(varNames, linkRrefs, sparqlResponseResults, booleans)
	}
	private var _seek = -1;

	val hasResults = results.nonEmpty;
	val hasLinks = linkHrefs.nonEmpty;
	val hasBooleans = booleans.nonEmpty;

	/**Returns a human readable representation of the results*/
	override def toString() = (for (i <- 0 until results.size)
		yield (results(i).map(r=>r.name + " = " + r.value).mkString(i + ": ", " ", "\n"))).mkString("");

	/**This method can be used to remove spaces, tabulations, new lines and
	 * other characters not needed for computation, but for visualization
	 * 
	 * @param sparql_res - human readable sparql_response
	 * @return sparql_response without characters not needed for computation
	 */
	private def formatString(sparqlRes:String) = {
		// replaces end of lines
		var newResponse = sparqlRes.replace("\n", "");

		// replaces double spaces
		while (newResponse.contains("  "))
			newResponse = newResponse.replaceAll("  ", " ");
		newResponse = newResponse.replace("> <", "><");
		newResponse;
	}


	/**Checks if seek is set to the maximum value possible (i.e. the results
	 * size)
	 * 
	 * @return true if it possible to get another result through getNextRow(),
	 *         false otherwise
	 */
	def hasNext() = size - 1 > seek;

	/**@return the number of the results inside the ssap sparql response*/
	def size = results.size;

	/**@param index
	 * @return a List<String[]> representing the single result row referred by
	 *         the index
	 */
	def getRow(index:Int) = apply(index);
	def apply(index:Int) = {
		if (results.size <= index)
			System.err.println("index out of bounds. The dimension of the result set is " + results.size);
		results(index);
	}

	/**Returns the result correspondding to the current value of seek
	 * @return a row of results */
	def getRow() = apply();
	def apply() = {
		if (results.size == seek) {
			System.err.println("SSAP_sparql_response already at the last element. Nothing done.");
			null;
		} else
			results(seek);
	}

	/**Returns the result correspondding to the next value of seek
	 * @return a row of results, or null if the end of results is reached */
	def next() = {
		if (seek < results.size){
			seek += 1;
			/*true;
		} else {
			System.err.println("SSAP_sparql_response already at the last element. Nothing done.");
			false;*/
		}
		getRow();
	}

	/**Gives the number of results for the current response or -1
	 * @return the number of results for the current response or -1 */
	def resultsNumber = if (results != null) results.size else -1;

	def seek = _seek;
	def seek_=(v:Int) {
		if (results.size <= v) 
			throw new IllegalArgumentException("ERROR: index out of bounds. The dimension of the result set is " + results.size);
		_seek = v;
	}

	/**This method returns all the <binding> elements with the specified variable name
	 * @param varname
	 * @return return a List<String[]> with all the <binding> elements
	 *         containing the specified variable name
	 */
	def getResultsForVar(varName:String) = results.flatten.filter(_.name==varName);

	def getValueForVarName(varName:String) = getRow()(variableNames.indexOf(varName)).value;

	def graph = {
		if (isQueryTypeConstruct)
			resultGraph;
		else {
			System.err.println("Sorry, this query is a sparql SELECT/ASK type. No graph to return");
			null;
		}
	}

	/**Print the RDF/XML representation of a graph returned in response to a CONSTRUCT or DESCRIBE query */
	def printGraph(graph:Element) {
		if (isQueryTypeConstruct)
			try {
				val baos = new ByteArrayOutputStream();
				new XMLOutputter().output(graph, baos);
				System.out.println(baos.toString());
			} catch {
			case e:Exception => System.err.println("This object represent the result of query that is a sparql SELECT/ASK type. No graph to print");
			}
		else
			System.err.println("Sorry, this query is a sparql SELECT/ASK type. No graph to print");
	}
}
