package sofia_kp.scala

import java.util._;
import scala.collection.JavaConverters._;
import scala.collection.mutable.Buffer;
import scala.io._;

class ArcesServiceRegistry(val registryUrl:String) {
	/**Search for all service registered on the service registry.
	 * @return Return an array of Properties. Each property contains all the
	 *         available parameters related to the service. The array could be
	 *         include zero, one or more that one property object, it depends on
	 *         the registry content
	 */
	def search():Seq[Properties] = search(null);

	/**Search for all service registered on the service registry that match the
	 * parameters value passed.
	 * @param serviceProperties
	 *            the service properties (e.g. p1=a, p2=b, kk=hello)
	 * @return Return an array of Properties. Each property contains all the
	 *         available parameters related to the service. The array could be
	 *         include zero, one or more that one property object, it depends on
	 *         the registry content.
	 */
	def search(serviceProperties:Properties) = {
		val getCommand = if (serviceProperties == null || serviceProperties == "") "" else serviceProperties.propertyNames.asScala.map(key=>"" + key + "=" + serviceProperties.getProperty(key toString)).mkString("&");
		val ret = readURL(registryUrl + "/search.php?" + getCommand);
		if (ret == null || ret.isEmpty)
			Nil;
		else {
			// From registry-string-format to properties:
			val lines = ret.split("\\n");
			if (lines.length == 0)
				Nil; // service not found
			else {
				val vSearchResult = Buffer[Properties]()
				for (line <- lines){
					val serviceFoundProperties = new Properties();

					for (serv <- line.split("\\|")){
						val param = serv.split("=");
						serviceFoundProperties.setProperty(param(0), param(1));	//name, value
					}
					if (serviceFoundProperties.size() > 0)
						vSearchResult += serviceFoundProperties;
				}
				vSearchResult;
			}
		}
	}

	/**Get a web page content by passing an url
	 * @param url	the url to invoke
	 * @return the web page content */
	private def readURL(url:String) = Source.fromURL(url).mkString;

	/**Add a service to the register
	 * @param serviceProperties
	 *            the service properties (e.g. p1=a, p2=b, kk=hello) that
	 *            describe the service
	 * @return Return the service response. It should be one of the following:
	 *         ERROR:Service NO_SERVICE_01 is already registered!ERROR:Please
	 *         check! ERROR:The "sid", service ID, is need ERROR:At least one
	 *         parameter is need! Use "sid" the service ID. OK:Done!<br>
	 *         Return null in case of unplanned error
	 */
	def add(serviceProperties:Properties) = {
		val getCommand = if (serviceProperties == null || serviceProperties == "") "" else serviceProperties.propertyNames.asScala.map(key=>"" + key + "=" + serviceProperties.getProperty(key toString)).mkString("&");
		val ret = this.readURL(registryUrl + "/add.php?" + getCommand);
		if (ret == null || ret.isEmpty)
			null;
		else
			ret;
	}

	/**Remove a service from the register
	 * @param serviceProperties
	 *            the service properties (e.g. p1=a, p2=b, kk=hello) that
	 *            describe the service
	 * @return Return the service response. It should be one of the following:
	 *         ERROR:The "sid", service ID, parameter is needed! ERROR:The
	 *         service "NO_SERVICE_01" is not registered yet! OK:Done!
	 *         Return null in case of unplanned error
	 */
	def remove(serviceProperties:Properties) = {
		val getCommand = if (serviceProperties == null || serviceProperties == "") "" else serviceProperties.propertyNames.asScala.map(key=>"" + key + "=" + serviceProperties.getProperty(key toString)).mkString("&");
		val ret = readURL(registryUrl + "/remove.php?" + getCommand);
		if (ret == null || ret.equals(""))
			null;
		else
			ret;
	}

	private def NewProperties(params:String) = {
		val userServiceSearch = new Properties();
		if (params != null && !params.isEmpty)
			for (serv <- params.split("\\|")){
				val param = serv.split("=");
				userServiceSearch.setProperty(param(0), param(1));	//name, value
			}
		userServiceSearch;
	}
}