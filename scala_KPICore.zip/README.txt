Scala KPI V1.0

derived by Java KPI V7.1

Read and execute resources/KPIPrimitiveUsage.scala to understand basic features and see simple examples.

Execute directly sofia_kp_scala.jar to run a GUI to interact with the SIB.

resources/JenaBasedOntologyLoader.scala is an untility to load ontology into SIB, it requires Jena libraries to be run (downloadable at https://jena.apache.org/download).
Those libraries are not directly included because of their dimensions and restrictions on directly including Jena liraries into external projects.
